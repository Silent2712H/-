﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsAppBaby.Entity;
using WindowsFormsAppBaby.Factory;

namespace WindowsFormsAppBaby
{
    public partial class Form1 : Form
    {
     
        List<s點餐分類> list點餐分類;
        s點餐分類 menu分類;
        void lv菜單分類()
        {
            list點餐分類 = (new s點餐分類Factory()).queryAll點餐分類();

            if (list點餐分類 != null)
            {       
                imageList1.Images.Clear();
                foreach (s點餐分類 item in list點餐分類)
                {
                    imageList1.Images.Add(Image.FromFile(GlobalVar.image分類圖檔相對路徑 + item.f圖片));
                }
                listView1.Clear();
                listView1.View = View.LargeIcon;
                imageList1.ImageSize = new Size(50, 50);
                listView1.LargeImageList = imageList1;
                ListViewItem 設定ListView每個item;
                for (int i = 0; i < imageList1.Images.Count; i++)
                {
                    設定ListView每個item = new ListViewItem();
                    設定ListView每個item.ImageIndex = i;
                    設定ListView每個item.Font = new Font("微軟正黑體", 10, FontStyle.Bold);
                    設定ListView每個item.Text = list點餐分類[i].f分類;
                    listView1.Items.Add(設定ListView每個item);
                }
            }
        }
        List<s餐廳> list對應餐廳;
        s餐廳 Rest;

        List<s餐點> list對應餐點;
        s餐點 currentmenu;

        void 對應餐廳(int fId)
        {
            list對應餐廳 = (new s餐廳Factory()).queryBy點餐分類(fId);

            if (list對應餐廳 != null)
            {
                cbox餐廳.Items.Clear();
                foreach (s餐廳 item in list對應餐廳)
                {
                    cbox餐廳.Items.Add(item.f餐廳名稱);
                }

                cbox餐廳.SelectedIndex = 0;
            }
        }

        void 對應餐點(int f分類Id, int f餐廳Id)
        {
            list對應餐點 = (new s餐點Factory()).queryBy點餐分類(f分類Id, f餐廳Id);

            if (list對應餐點 != null)
            {
                lbox菜單.Items.Clear();
                foreach (s餐點 item in list對應餐點)
                {
                    lbox菜單.Items.Add(item.f餐點);
                }
            }
        }

        int int數量;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = GlobalVar.version版本;

            if ((GlobalOrder.e目前訂購單位 == null) || (GlobalOrder.e目前訂購人 == null))
            {
                Form form登入 = new Form登入();
                form登入.ShowDialog();
            }

            if (GlobalOrder.e目前訂購單位.fId == 0)
            {
                
                btn餐點管理.Visible = true;
            }
            else
            {
                
                btn餐點管理.Visible = false;
            }


            txt訂購單位.Text = GlobalOrder.e目前訂購單位.f訂購單位;
            txt訂購人.Text = $"{GlobalOrder.e目前訂購人.f姓名} [{GlobalOrder.e目前訂購人.fId}]";

            list點餐分類 = null;
            menu分類 = null;
            list對應餐廳 = null;
            Rest = null;
            list對應餐點 = null;
            currentmenu = null;
            int數量 = 1;

            cbox餐廳.Text = "請點選食物品類";
            cbox餐廳.Items.Clear();
            lbox菜單.Items.Clear();
            nud數量.Value = 1;
            txt單價.Text = "";
            txt小計.Text = "";
            txt系統訊息.Text = "歡迎使用本系統";

            GlobalVar.store目前餐廳資訊 = null;

            lv菜單分類();

            read載入我的最愛(GlobalOrder.e目前訂購人.fId);
        }

        private void listView1_ItemActivate(object sender, EventArgs e)
        {
            list對應餐廳 = null;
            Rest = null;
            list對應餐點 = null;
            currentmenu = null;
            int數量 = 1;

            cbox餐廳.Items.Clear();
            lbox菜單.Items.Clear();
            nud數量.Value = 1;
            txt單價.Text = "";
            txt小計.Text = "";
            txt系統訊息.Text = "歡迎使用本系統";

            GlobalVar.store目前餐廳資訊 = null;

            if (listView1.SelectedIndices[0] > -1)
            {
                menu分類 = list點餐分類[listView1.SelectedIndices[0]];

                對應餐廳(menu分類.fId);
            }
        }

        private void cbox餐廳_SelectedIndexChanged(object sender, EventArgs e)
        {

            list對應餐點 = null;
            currentmenu = null;
            int數量 = 1;

            lbox菜單.Items.Clear();
            nud數量.Value = 1;
            txt單價.Text = "";
            txt小計.Text = "";
            txt系統訊息.Text = "歡迎使用本系統";

            if (cbox餐廳.SelectedIndex > -1)
            {

                Rest = list對應餐廳[cbox餐廳.SelectedIndex];

                對應餐點(menu分類.fId, Rest.fId);

                GlobalVar.store目前餐廳資訊 = (new s餐廳Factory()).query餐廳(Rest.fId);
            }
        }


        private void lbox菜單_SelectedIndexChanged(object sender, EventArgs e)
        {
            int數量 = 1;
            nud數量.Value = 1;
            txt系統訊息.Text = "歡迎使用本系統";

            if (lbox菜單.SelectedIndex > -1)
            {
                currentmenu = list對應餐點[lbox菜單.SelectedIndex];

                txt單價.Text = currentmenu.f價格.ToString();

                try
                {
                    pbox餐點圖.Image = Image.FromFile(GlobalVar.image菜單圖檔相對路徑 + currentmenu.f圖片);
                }
                catch
                {
                    pbox餐點圖.Image = Image.FromFile(GlobalVar.image菜單圖檔相對路徑 + @"default.png");
                }
                total計算總價(currentmenu.f價格, int數量);
            }
        }

        private void nud數量_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                int數量 = Convert.ToInt32(nud數量.Value);
                if (currentmenu != null)
                {
                    total計算總價(currentmenu.f價格, int數量);
                }
                txt系統訊息.Text = "歡迎使用本系統";
            }
            catch
            {
                int數量 = 1;
                nud數量.Value = 1;
                txt系統訊息.Text = "輸入錯誤,請重新輸入";
            }
        }

        int total計算總價(int int單價, int int數量)
        {
            txt小計.Text = (int單價 * int數量).ToString();
            return int單價 * int數量;
        }

        private void btn加入訂購單_Click(object sender, EventArgs e)
        {
            if (currentmenu != null)
            {
                s訂單明細 s = new s訂單明細();
                s.f訂購人Id = GlobalOrder.e目前訂購人.fId;
                s.f餐點Id = currentmenu.fId;
                s.f數量 = int數量;
                s.a單位Id = GlobalOrder.e目前訂購單位.fId;
                s.a餐廳Id = currentmenu.f餐廳Id;
                GlobalOrder.list訂單明細.Add(s);
                txt系統訊息.Text = "訂購成功";
            }
            else
            {
                txt系統訊息.Text = "訂購失敗 請選擇餐點！";
            }
        }

        private void btn查看訂購單_Click(object sender, EventArgs e)
        {
            Form form訂單列表 = new Form2();
            form訂單列表.ShowDialog();
        }

        private void btn登出_Click(object sender, EventArgs e)
        {
            GlobalOrder.e目前訂購單位 = null;
            GlobalOrder.e目前訂購人 = null;

            Form form登入 = new Form登入();
            form登入.ShowDialog();

            if (GlobalOrder.e目前訂購單位.fId == 0)
            {

                btn餐點管理.Visible = true;
            }
            else
            {

                btn餐點管理.Visible = false;
            }

 
            txt訂購單位.Text = GlobalOrder.e目前訂購單位.f訂購單位;
            txt訂購人.Text = $"{GlobalOrder.e目前訂購人.f姓名} [{GlobalOrder.e目前訂購人.fId}]";


            list點餐分類 = null;
            menu分類 = null;
            list對應餐廳 = null;
            Rest = null;
            list對應餐點 = null;
            currentmenu = null;
            int數量 = 1;

            cbox餐廳.Text = "請點選食物品類";
            cbox餐廳.Items.Clear();
            lbox菜單.Items.Clear();
            nud數量.Value = 1;
            txt單價.Text = "";
            txt小計.Text = "";
            txt系統訊息.Text = "歡迎使用本系統";

            lv菜單分類();

            read載入我的最愛(GlobalOrder.e目前訂購人.fId);
        }

        private void btn餐點管理_Click(object sender, EventArgs e)
        {
            Form form餐點管理 = new Form餐點管理();
            form餐點管理.ShowDialog();
        }

        private void btn我的最愛_Click(object sender, EventArgs e)
        {
            Form form我的最愛 = new Form我的最愛();
            form我的最愛.ShowDialog();
        }

        private void btn加入我的最愛_Click(object sender, EventArgs e)
        {
            if (currentmenu != null)
            {
                s訂單明細 s = new s訂單明細();
                s.f訂購人Id = GlobalOrder.e目前訂購人.fId;
                s.f餐點Id = currentmenu.fId;
                s.f數量 = int數量;
                s.a單位Id = GlobalOrder.e目前訂購單位.fId;
                s.a餐廳Id = currentmenu.f餐廳Id;
                GlobalOrder.list我的最愛.Add(s);
                txt系統訊息.Text = "成功加入我的最愛！";
            }
        }
       
        void read載入我的最愛(int fId訂購人)
        {           
            GlobalOrder.list我的最愛.Clear();         
            s訂購人 w = (new s訂購人Factory()).query訂購人(fId訂購人);
            if (w != null)
            {
                if (!string.IsNullOrEmpty(w.f我的最愛))
                {
                    s訂單明細 s;
                    s餐點 s餐;

                    string[] array我的最愛 = w.f我的最愛.Split('|');
                    string[] array每個最愛編號數量;
                    foreach (string item in array我的最愛)
                    {
                        if (!string.IsNullOrEmpty(item))
                        {
                            s = new s訂單明細();
                            array每個最愛編號數量 = item.Split(',');
                            s.f訂購人Id = GlobalOrder.e目前訂購人.fId;
                            s.f餐點Id = Convert.ToInt32(array每個最愛編號數量[0]);
                            s.f數量 = Convert.ToInt32(array每個最愛編號數量[1]);
                            s.a單位Id = GlobalOrder.e目前訂購單位.fId;
                            s餐 = (new s餐點Factory()).queryById(Convert.ToInt32(array每個最愛編號數量[0]));
                            s.a餐廳Id = s餐.f餐廳Id;
                            GlobalOrder.list我的最愛.Add(s);
                        }
                    }
                }
            }
        }

       
    }
}
