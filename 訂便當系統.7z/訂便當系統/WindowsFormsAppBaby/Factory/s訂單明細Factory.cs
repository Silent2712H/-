﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsAppBaby.Entity;

namespace WindowsFormsAppBaby.Factory
{
    class s訂單明細Factory
    {
        public void create(s訂單明細 orderdetail)
        {
            string sql = "insert into t訂單明細(f訂單Id, f訂購人Id, f餐點Id, f數量) values(@f訂單Id, @f訂購人Id, @f餐點Id, @f數量)";

            List<SqlParameter> paras = new List<SqlParameter>();
            paras.Add(new SqlParameter("f訂單Id", (object)orderdetail.f訂單Id));
            paras.Add(new SqlParameter("f訂購人Id", (object)orderdetail.f訂購人Id));
            paras.Add(new SqlParameter("f餐點Id", (object)orderdetail.f餐點Id));
            paras.Add(new SqlParameter("f數量", (object)orderdetail.f數量));

            changeBysql(sql, paras);
        }

        public void changeBysql(string sql, List<SqlParameter> paras)
        {
            SqlConnection con = new SqlConnection(GlobalVar.sqlstring);
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            if (paras != null)
            {
                foreach (SqlParameter p in paras)
                    cmd.Parameters.Add(p);
            }
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
