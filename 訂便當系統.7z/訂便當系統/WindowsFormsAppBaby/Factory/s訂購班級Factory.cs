﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsAppBaby.Entity;

namespace WindowsFormsAppBaby.Factory
{
    class s訂購班級Factory
    {
        public List<s訂購班級> queryAll訂購單位()
        {
            List<s訂購班級> list = queryBysql("select * from t訂購單位");
            if (list.Count == 0)
            {
                return null;
            }      
            return list;
        }

        public s訂購班級 query指定訂購單位Id(int fId)
        {
            List<s訂購班級> list = queryBysql($"select * from t訂購單位 where fId = {fId}");

            if (list.Count == 0)
            {
                return null;
            }
            return list[0];
        }

        public s訂購班級 query指定訂購人(int fId)
        {
            s訂購人 p = (new s訂購人Factory()).query訂購人(fId);
            if (p != null)
            {
                List<s訂購班級> list = queryBysql($"select * from t訂購單位 where fId = {p.f訂購單位Id}");

                if (list.Count == 0)
                {
                    return null;
                }
                return list[0];
            }
            else
            {
                return null;
            }
        }

        public List<s訂購班級> queryBysql(string sql)
        {
         
            SqlConnection con = new SqlConnection(GlobalVar.sqlstring);
            con.Open();        
            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);          
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            con.Close();

            List<s訂購班級> list = new List<s訂購班級>();
            s訂購班級 x;
            foreach (DataRow r in ds.Tables[0].Rows)
            {
                x = new s訂購班級();
                x.fId = Convert.ToInt32(r["fId"].ToString());
                x.f訂購單位 = r["f訂購單位"].ToString();
                list.Add(x);
            }
            return list;
        }

        //新增
        public void create(s訂購班級 p)
        {
            string sql = "insert into t訂購單位(f訂購單位) values(@f訂購單位)";

            List<SqlParameter> paras = new List<SqlParameter>();
            paras.Add(new SqlParameter("f訂購單位", (object)p.f訂購單位));

            queryBysql(sql, paras);
        }

        //修改
        public void update(s訂購班級 p)
        {
            string sql = "update t訂購單位 set f訂購單位 = @f訂購單位 where fId = @fId";

            List<SqlParameter> paras = new List<SqlParameter>();
            paras.Add(new SqlParameter("fId", (object)p.fId));
            paras.Add(new SqlParameter("f訂購單位", (object)p.f訂購單位));

            queryBysql(sql, paras);
        }

        //刪除
        public void delete(s訂購班級 p)
        {
            string sql = "delete from t訂購單位 where fId = @fId";

            List<SqlParameter> paras = new List<SqlParameter>();
            paras.Add(new SqlParameter("fId", (object)p.fId));

            queryBysql(sql, paras);
        }

        public void queryBysql(string sql, List<SqlParameter> paras)
        {
            SqlConnection con = new SqlConnection(GlobalVar.sqlstring);
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            if (paras != null)
            {
                foreach (SqlParameter p in paras)
                    cmd.Parameters.Add(p);
            }

            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
