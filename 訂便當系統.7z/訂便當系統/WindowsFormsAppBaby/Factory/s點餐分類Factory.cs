﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsAppBaby.Entity;

namespace WindowsFormsAppBaby.Factory
{
    class s點餐分類Factory
    {
        public List<s點餐分類> queryAll點餐分類()
        {
            List<s點餐分類> list = queryBysql("select * from t點餐分類");
         
            if (list.Count == 0)
            {
                return null;
            }
            return list;
        }

        public s點餐分類 queryById(int fId)
        {
            List<s點餐分類> list = queryBysql($"select * from t點餐分類 where fId = {fId}");

            if (list.Count == 0)
            {
                return null;
            }              
            return list[0];
        }

        public List<s點餐分類> queryBysql(string sql)
        {
            SqlConnection con = new SqlConnection(GlobalVar.sqlstring);
            con.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            con.Close();

            List<s點餐分類> list = new List<s點餐分類>();
            s點餐分類 x;
            foreach (DataRow r in ds.Tables[0].Rows)
            {
                x = new s點餐分類();
                x.fId = Convert.ToInt32(r["fId"].ToString());
                x.f分類 = r["f分類"].ToString();
                x.f圖片 = r["f圖片"].ToString();
                list.Add(x);
            }
            return list;
        }
    }
}
