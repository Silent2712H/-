﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsAppBaby.Entity;

namespace WindowsFormsAppBaby.Factory
{
    class s餐廳Factory
    {
        public List<s餐廳> queryAll餐廳()
        {
            List<s餐廳> list = queryBysql("select * from t餐廳");
            if (list.Count == 0)
            {
                return null;
            }
            return list;
        }

        public List<s餐廳> queryBy點餐分類(int fId)
        {
            List<s餐廳> list = queryBysql("select distinct B.fId, B.f餐廳名稱, B.f餐廳電話, B.f餐廳地址 from t餐點 as A join t餐廳 as B on A.f餐廳Id = B.fId where A.f分類Id = " + fId);

            if (list.Count == 0)
            {
                return null;
            }   
            return list;
        }
        public s餐廳 query餐廳(int fId)
        {
            List<s餐廳> list = queryBysql($"select * from t餐廳 where fId = {fId}");
            if (list.Count == 0)
            {
                return null;
            }
            return list[0];
        }

        public List<s餐廳> queryBysql(string sql)
        {
            SqlConnection con = new SqlConnection(GlobalVar.sqlstring);
            con.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            con.Close();

            List<s餐廳> list = new List<s餐廳>();
            s餐廳 x;
            foreach (DataRow r in ds.Tables[0].Rows)
            {
                x = new s餐廳();
                x.fId = Convert.ToInt32(r["fId"].ToString());
                x.f餐廳名稱 = r["f餐廳名稱"].ToString();
                x.f餐廳電話 = r["f餐廳電話"].ToString();
                x.f餐廳地址 = r["f餐廳地址"].ToString();
                list.Add(x);
            }
            return list;
        }

        //新增
        public void create(s餐廳 p)
        {
            string sql = "insert into t餐廳(f餐廳名稱, f餐廳電話, f餐廳地址) ";
            sql += "values(@f餐廳名稱, @f餐廳電話, @f餐廳地址)";

            List<SqlParameter> paras = new List<SqlParameter>();
            paras.Add(new SqlParameter("f餐廳名稱", (object)p.f餐廳名稱));
            paras.Add(new SqlParameter("f餐廳電話", (object)p.f餐廳電話));
            paras.Add(new SqlParameter("f餐廳地址", (object)p.f餐廳地址));

            queryBysql(sql, paras);
        }

        //修改
        public void update(s餐廳 p)
        {
            string sql = "update t餐廳 set f餐廳名稱 = @f餐廳名稱, f餐廳電話 = @f餐廳電話, f餐廳地址 = @f餐廳地址";
            sql += " where fId = @fId";

            List<SqlParameter> paras = new List<SqlParameter>();
            paras.Add(new SqlParameter("fId", (object)p.fId));
            paras.Add(new SqlParameter("f餐廳名稱", (object)p.f餐廳名稱));
            paras.Add(new SqlParameter("f餐廳電話", (object)p.f餐廳電話));
            paras.Add(new SqlParameter("f餐廳地址", (object)p.f餐廳地址));

            queryBysql(sql, paras);
        }

        //刪除
        public void delete(s餐廳 p)
        {
            string sql = "delete from t餐廳 where fId = @fId";

            List<SqlParameter> paras = new List<SqlParameter>();
            paras.Add(new SqlParameter("fId", (object)p.fId));

            queryBysql(sql, paras);
        }

        public void queryBysql(string sql, List<SqlParameter> paras)
        {
            SqlConnection con = new SqlConnection(GlobalVar.sqlstring);
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            if (paras != null)
            {
                foreach (SqlParameter p in paras)
                    cmd.Parameters.Add(p);
            }
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
