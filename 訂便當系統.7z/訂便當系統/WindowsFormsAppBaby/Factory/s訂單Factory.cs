﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsAppBaby.Entity;

namespace WindowsFormsAppBaby.Factory
{
    class s訂單Factory
    {
      
        public s訂單 query最新訂單()
        {
            string sql = "select * from t訂單";
            List<s訂單> all訂單 = queryBysql(sql, null);
            if (all訂單.Count > 0)
            {
                return all訂單[all訂單.Count - 1];
            }
            else
            {
                return null;
            }
        }

        public List<s訂單> queryBysql(string sql, List<SqlParameter> paras)
        {
       
            SqlConnection con = new SqlConnection(GlobalVar.sqlstring);
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            if (paras != null)
            {
                foreach (SqlParameter p in paras)
                    cmd.Parameters.Add(p);
            }
   
            SqlDataReader reader = cmd.ExecuteReader();
            List<s訂單> list = new List<s訂單>();
            s訂單 s;
            while (reader.Read())
            {
                s = new s訂單();
                s.fId = (int)reader["fId"];
                s.f訂單時間 = (DateTime)reader["f訂單時間"];
                list.Add(s);
            }
            con.Close();

            return list;
        }

        //新增
        public void create(s訂單 order)
        {
            string sql = "insert into t訂單(f訂單時間) values(@f訂單時間)";

            List<SqlParameter> paras = new List<SqlParameter>();
            paras.Add(new SqlParameter("f訂單時間", (object)order.f訂單時間));

            changeBysql(sql, paras);
        }

       
        public void changeBysql(string sql, List<SqlParameter> paras)
        {
         
            SqlConnection con = new SqlConnection(GlobalVar.sqlstring);
            con.Open();          
            SqlCommand cmd = new SqlCommand(sql, con);
            if (paras != null)
            {
                foreach (SqlParameter p in paras)
                    cmd.Parameters.Add(p);
            }
           
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
