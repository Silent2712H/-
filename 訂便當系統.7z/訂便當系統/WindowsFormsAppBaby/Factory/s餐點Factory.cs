﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsAppBaby.Entity;

namespace WindowsFormsAppBaby.Factory
{
    class s餐點Factory
    {
        
        public List<s餐點> queryBy點餐分類(int f分類Id, int f餐廳Id)
        {
            List<s餐點> list = queryBysql($"select * from t餐點 where f分類Id = {f分類Id} and f餐廳Id = {f餐廳Id}");

            if (list.Count == 0)
            {
                return null;
            }
            return list;
        }

       
        public List<s餐點> queryBy餐廳(int f餐廳Id)
        {
            List<s餐點> list = queryBysql($"select * from t餐點 where f餐廳Id = {f餐廳Id}");

            if (list.Count == 0)
            {
                return null;
            }
            return list;
        }

     
        public s餐點 queryById(int fId)
        {
            List<s餐點> list = queryBysql($"select * from t餐點 where fId = {fId}");

            if (list.Count == 0)
            {
                return null;
            }  
            return list[0];
        }

        public List<s餐點> queryBysql(string sql)
        {
            SqlConnection con = new SqlConnection(GlobalVar.sqlstring);
            con.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            con.Close();

            List<s餐點> list = new List<s餐點>();
            s餐點 x;
            foreach (DataRow r in ds.Tables[0].Rows)
            {
                x = new s餐點();
                x.fId = Convert.ToInt32(r["fId"].ToString());
                x.f分類Id = Convert.ToInt32(r["f分類Id"].ToString());
                x.f餐廳Id = Convert.ToInt32(r["f餐廳Id"].ToString());
                x.f餐點 = r["f餐點"].ToString();
                x.f價格 = Convert.ToInt32(r["f價格"].ToString());
                x.f圖片 = r["f圖片"].ToString();
                list.Add(x);
            }
            return list;
        }

        //新增
        public void create(s餐點 p)
        {
            string sql = "insert into t餐點(f分類Id, f餐廳Id, f餐點, f價格, f圖片) ";
            sql += "values(@f分類Id, @f餐廳Id, @f餐點, @f價格, @f圖片)";

            List<SqlParameter> paras = new List<SqlParameter>();
            paras.Add(new SqlParameter("f分類Id", (object)p.f分類Id));
            paras.Add(new SqlParameter("f餐廳Id", (object)p.f餐廳Id));
            paras.Add(new SqlParameter("f餐點", (object)p.f餐點));
            paras.Add(new SqlParameter("f價格", (object)p.f價格));
            paras.Add(new SqlParameter("f圖片", (object)p.f圖片));

            queryBysql(sql, paras);
        }

        //修改
        public void update(s餐點 p)
        {
            string sql = "update t餐點 set f分類Id = @f分類Id, f餐廳Id = @f餐廳Id, f餐點 = @f餐點, f價格 = @f價格, f圖片 = @f圖片";
            sql += " where fId = @fId";

            List<SqlParameter> paras = new List<SqlParameter>();
            paras.Add(new SqlParameter("fId", (object)p.fId));
            paras.Add(new SqlParameter("f分類Id", (object)p.f分類Id));
            paras.Add(new SqlParameter("f餐廳Id", (object)p.f餐廳Id));
            paras.Add(new SqlParameter("f餐點", (object)p.f餐點));
            paras.Add(new SqlParameter("f價格", (object)p.f價格));
            paras.Add(new SqlParameter("f圖片", (object)p.f圖片));

            queryBysql(sql, paras);
        }

        //刪除
        public void delete(s餐點 p)
        {
            string sql = "delete from t餐點 where fId = @fId";

            List<SqlParameter> paras = new List<SqlParameter>();
            paras.Add(new SqlParameter("fId", (object)p.fId));

            queryBysql(sql, paras);
        }

       
        public void queryBysql(string sql, List<SqlParameter> paras)
        {         
            SqlConnection con = new SqlConnection(GlobalVar.sqlstring);
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            if (paras != null)
            {
                foreach (SqlParameter p in paras)
                    cmd.Parameters.Add(p);
            }
          
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
