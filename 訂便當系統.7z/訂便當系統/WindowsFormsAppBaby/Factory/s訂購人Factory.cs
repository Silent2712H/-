﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsAppBaby.Entity;

namespace WindowsFormsAppBaby.Factory
{
    class s訂購人Factory
    {
        
        public List<s訂購人> query單位訂購人(int fId)
        {
            List<s訂購人> list = queryBysql($"select * from t訂購人 where f訂購單位Id = {fId}");
            
            if (list.Count == 0)
            {
                return null;
            }
            return list;
        }

        
        public s訂購人 query單位值日生(int fId)
        {
            List<s訂購人> list = queryBysql($"select * from t訂購人 where f訂購單位Id = {fId} and f值日生權限 = 1");

            if (list.Count == 0)
            {
                return null;
            }
            return list[0];
        }

        
        public s訂購人 query訂購人(int fId)
        {
            List<s訂購人> list = queryBysql($"select * from t訂購人 where fId = {fId}");
           
            if (list.Count == 0)
            {
                return null;
            }
              
            return list[0];
        }

        public s訂購人 next值日生(s訂購人 person)
        {
            List<int> list = queryBysql("select * from t訂購人").Where(p => p.f訂購單位Id == person.f訂購單位Id).Select(p => p.fId).ToList();
            if (list.Count > 0)
            {
                int first = list[0];
                s訂購人 first訂購人 = (new s訂購人Factory()).query訂購人(first);
                int rank = list.IndexOf(person.fId);
                if (rank != -1)
                {
                  
                    if (rank == list.Count - 1)
                    {
                        return first訂購人;
                    }
                    else
                    {
                        return (new s訂購人Factory()).query訂購人(list[rank + 1]);
                    }
                }
            }
            return null;
        }

        public List<s訂購人> queryBysql(string sql)
        {
  
            SqlConnection con = new SqlConnection(GlobalVar.sqlstring);
            con.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            con.Close();

            List<s訂購人> list = new List<s訂購人>();
            s訂購人 x;
            foreach (DataRow r in ds.Tables[0].Rows)
            {
                x = new s訂購人();
                x.fId = Convert.ToInt32(r["fId"].ToString());
                x.f姓名 = r["f姓名"].ToString();
                x.f密碼 = r["f密碼"].ToString();
                x.f訂購單位Id = Convert.ToInt32(r["f訂購單位Id"].ToString());
                x.f值日生權限 = (bool)r["f值日生權限"];
                x.f我的最愛 = r["f我的最愛"].ToString();
                list.Add(x);
            }
            return list;
        }

        // 新增
        public void create(s訂購人 p)
        {
            string sql = "insert into t訂購人(f姓名, f密碼, f訂購單位Id, f值日生權限, f我的最愛) ";
            sql += "values(@f姓名, @f密碼, @f訂購單位Id, @f值日生權限, @f我的最愛)";

            List<SqlParameter> paras = new List<SqlParameter>();
            paras.Add(new SqlParameter("f姓名", (object)p.f姓名));
            paras.Add(new SqlParameter("f密碼", (object)p.f密碼));
            paras.Add(new SqlParameter("f訂購單位Id", (object)p.f訂購單位Id));
            paras.Add(new SqlParameter("f值日生權限", (object)p.f值日生權限));
            paras.Add(new SqlParameter("f我的最愛", (object)p.f我的最愛));

            queryBysql(sql, paras);
        }

        //修改
        public void update(s訂購人 p)
        {
            string sql = "update t訂購人 set ";
         
            if (!string.IsNullOrEmpty(p.f姓名) && !string.IsNullOrEmpty(p.f密碼))
            {
                sql += "f姓名 = @f姓名, f密碼 = @f密碼";
            }
         
            else if (!string.IsNullOrEmpty(p.f我的最愛))
            {
                sql += "f我的最愛 = @f我的最愛";
            }
        
            else
            {
                sql += "f值日生權限 = @f值日生權限";
            }
            sql += " where fId = @fId";

            List<SqlParameter> paras = new List<SqlParameter>();
            paras.Add(new SqlParameter("fId", (object)p.fId));
           
            if (!string.IsNullOrEmpty(p.f姓名) && !string.IsNullOrEmpty(p.f密碼))
            {
                paras.Add(new SqlParameter("f姓名", (object)p.f姓名));
                paras.Add(new SqlParameter("f密碼", (object)p.f密碼));
            }
            
            else if (!string.IsNullOrEmpty(p.f我的最愛))
            {
                paras.Add(new SqlParameter("f我的最愛", (object)p.f我的最愛));
            }
         
            else
            {
                paras.Add(new SqlParameter("f值日生權限", (object)p.f值日生權限));
            }

            queryBysql(sql, paras);
        }

        //刪除
        public void delete(s訂購人 p)
        {
            string sql = "delete from t訂購人 where fId = @fId";

            List<SqlParameter> paras = new List<SqlParameter>();
            paras.Add(new SqlParameter("fId", (object)p.fId));

            queryBysql(sql, paras);
        }

      
        public void queryBysql(string sql, List<SqlParameter> paras)
        {
         
            SqlConnection con = new SqlConnection(GlobalVar.sqlstring);
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            if (paras != null)
            {
                foreach (SqlParameter p in paras)
                    cmd.Parameters.Add(p);
            }
            
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
