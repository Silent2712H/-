﻿namespace WindowsFormsAppBaby
{
    partial class Form我的最愛
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbox我的最愛 = new System.Windows.Forms.ListBox();
            this.btn刪除選取 = new System.Windows.Forms.Button();
            this.btn清空全部 = new System.Windows.Forms.Button();
            this.btn全部加入訂購單 = new System.Windows.Forms.Button();
            this.txt系統訊息 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl總價 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbox我的最愛
            // 
            this.lbox我的最愛.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbox我的最愛.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbox我的最愛.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lbox我的最愛.FormattingEnabled = true;
            this.lbox我的最愛.ItemHeight = 25;
            this.lbox我的最愛.Location = new System.Drawing.Point(21, 108);
            this.lbox我的最愛.Name = "lbox我的最愛";
            this.lbox我的最愛.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lbox我的最愛.Size = new System.Drawing.Size(437, 154);
            this.lbox我的最愛.TabIndex = 7;
            this.lbox我的最愛.SelectedIndexChanged += new System.EventHandler(this.lbox我的最愛_SelectedIndexChanged);
            // 
            // btn刪除選取
            // 
            this.btn刪除選取.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btn刪除選取.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn刪除選取.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn刪除選取.Location = new System.Drawing.Point(186, 273);
            this.btn刪除選取.Name = "btn刪除選取";
            this.btn刪除選取.Size = new System.Drawing.Size(122, 46);
            this.btn刪除選取.TabIndex = 34;
            this.btn刪除選取.Text = "移除訂單";
            this.btn刪除選取.UseVisualStyleBackColor = false;
            this.btn刪除選取.Click += new System.EventHandler(this.btn刪除選取_Click);
            // 
            // btn清空全部
            // 
            this.btn清空全部.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btn清空全部.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn清空全部.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn清空全部.Location = new System.Drawing.Point(329, 273);
            this.btn清空全部.Name = "btn清空全部";
            this.btn清空全部.Size = new System.Drawing.Size(129, 46);
            this.btn清空全部.TabIndex = 35;
            this.btn清空全部.Text = "全部移除";
            this.btn清空全部.UseVisualStyleBackColor = false;
            this.btn清空全部.Click += new System.EventHandler(this.btn清空全部_Click);
            // 
            // btn全部加入訂購單
            // 
            this.btn全部加入訂購單.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btn全部加入訂購單.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn全部加入訂購單.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn全部加入訂購單.Location = new System.Drawing.Point(550, 108);
            this.btn全部加入訂購單.Name = "btn全部加入訂購單";
            this.btn全部加入訂購單.Size = new System.Drawing.Size(59, 168);
            this.btn全部加入訂購單.TabIndex = 36;
            this.btn全部加入訂購單.Text = "加入訂購單";
            this.btn全部加入訂購單.UseVisualStyleBackColor = false;
            this.btn全部加入訂購單.Click += new System.EventHandler(this.全部加入訂購單_Click);
            // 
            // txt系統訊息
            // 
            this.txt系統訊息.Location = new System.Drawing.Point(21, 58);
            this.txt系統訊息.Multiline = true;
            this.txt系統訊息.Name = "txt系統訊息";
            this.txt系統訊息.ReadOnly = true;
            this.txt系統訊息.Size = new System.Drawing.Size(347, 42);
            this.txt系統訊息.TabIndex = 37;
            this.txt系統訊息.Text = "系統訊息欄";
            this.txt系統訊息.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt系統訊息.UseWaitCursor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(424, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 31);
            this.label1.TabIndex = 39;
            this.label1.Text = "總價";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbl總價
            // 
            this.lbl總價.BackColor = System.Drawing.Color.White;
            this.lbl總價.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl總價.Location = new System.Drawing.Point(492, 55);
            this.lbl總價.Name = "lbl總價";
            this.lbl總價.Size = new System.Drawing.Size(117, 42);
            this.lbl總價.TabIndex = 40;
            this.lbl總價.Text = "xx 元";
            this.lbl總價.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Blue;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(-8, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(631, 47);
            this.label2.TabIndex = 41;
            this.label2.Text = "<全端便當訂購系統>";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form我的最愛
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(621, 356);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbl總價);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt系統訊息);
            this.Controls.Add(this.btn全部加入訂購單);
            this.Controls.Add(this.btn清空全部);
            this.Controls.Add(this.btn刪除選取);
            this.Controls.Add(this.lbox我的最愛);
            this.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Form我的最愛";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "全端便當訂購系統";
            this.Load += new System.EventHandler(this.Form我的最愛_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ListBox lbox我的最愛;
        private System.Windows.Forms.Button btn刪除選取;
        private System.Windows.Forms.Button btn清空全部;
        private System.Windows.Forms.Button btn全部加入訂購單;
        private System.Windows.Forms.TextBox txt系統訊息;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl總價;
        private System.Windows.Forms.Label label2;
    }
}