﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsAppBaby.Entity;
using WindowsFormsAppBaby.Factory;

namespace WindowsFormsAppBaby
{
    public partial class Form我的最愛 : Form
    {
        public Form我的最愛()
        {
            InitializeComponent();
        }

        private void Form我的最愛_Load(object sender, EventArgs e)
        {
            this.Text = GlobalVar.version版本;

            我的最愛();
        }

        void 我的最愛()
        {
            lbox我的最愛.Items.Clear();
            lbl總價.Text = "";
            txt系統訊息.Text = "系統訊息欄";

            if (GlobalOrder.list我的最愛.Count > 0)
            {
                s餐點 s餐;
                s餐廳 s廳;
                foreach (s訂單明細 item in GlobalOrder.list我的最愛)
                {
                    s餐 = (new s餐點Factory()).queryById(item.f餐點Id);
                    s廳 = (new s餐廳Factory()).query餐廳(item.a餐廳Id);
                    lbox我的最愛.Items.Add($"{s廳.f餐廳名稱} － {s餐.f餐點}：{s餐.f價格}元 x {item.f數量}個");
                }
                total計算總價(GlobalOrder.list我的最愛);
            }
        }

        int total計算總價(List<s訂單明細> list訂單明細)
        {
            int int總價 = 0;
            if (list訂單明細.Count > 0)
            {
                s餐點 c餐;
                foreach (s訂單明細 item in list訂單明細)
                {
                    c餐 = (new s餐點Factory()).queryById(item.f餐點Id);
                    int總價 += item.f數量 * c餐.f價格;
                }
                lbl總價.Text = int總價.ToString() + " 元";
            }
            else
            {
                lbl總價.Text = "";
            }
            return int總價;
        }

        private void lbox我的最愛_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        //刪除
        private void btn刪除選取_Click(object sender, EventArgs e)
        {
            if (lbox我的最愛.SelectedIndices.Count > 0)
            {
                for (int i = lbox我的最愛.SelectedIndices.Count - 1; i >= 0; i--)
                {
                    GlobalOrder.list我的最愛.RemoveAt(lbox我的最愛.SelectedIndices[i]);
                }
                我的最愛();
            } 
        }

        private void btn清空全部_Click(object sender, EventArgs e)
        {
            GlobalOrder.list我的最愛.Clear();
            我的最愛();
        }

        private void 全部加入訂購單_Click(object sender, EventArgs e)
        {
            if (GlobalOrder.list我的最愛.Count > 0)
            {
                foreach (s訂單明細 item in GlobalOrder.list我的最愛)
                {
                    GlobalOrder.list訂單明細.Add(item);
                }
                txt系統訊息.Text = "已加入訂購單";
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
