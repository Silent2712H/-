﻿namespace WindowsFormsAppBaby
{
    partial class Form餐點管理
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbox餐廳 = new System.Windows.Forms.ComboBox();
            this.btn刪除餐廳 = new System.Windows.Forms.Button();
            this.btn新增餐廳 = new System.Windows.Forms.Button();
            this.cbox餐點 = new System.Windows.Forms.ComboBox();
            this.btn刪除餐點 = new System.Windows.Forms.Button();
            this.btn新增餐點 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btn修改餐點 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cbox餐點分類 = new System.Windows.Forms.ComboBox();
            this.nud餐點價格 = new System.Windows.Forms.NumericUpDown();
            this.btn修改餐點資料 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txt餐點名稱 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.pbox餐點圖 = new System.Windows.Forms.PictureBox();
            this.btn上傳圖片 = new System.Windows.Forms.Button();
            this.btn修改餐廳資料 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txt餐廳名稱 = new System.Windows.Forms.TextBox();
            this.txt餐廳電話 = new System.Windows.Forms.TextBox();
            this.txt餐廳地址 = new System.Windows.Forms.TextBox();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud餐點價格)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox餐點圖)).BeginInit();
            this.SuspendLayout();
            // 
            // cbox餐廳
            // 
            this.cbox餐廳.BackColor = System.Drawing.Color.White;
            this.cbox餐廳.FormattingEnabled = true;
            this.cbox餐廳.Location = new System.Drawing.Point(113, 59);
            this.cbox餐廳.Name = "cbox餐廳";
            this.cbox餐廳.Size = new System.Drawing.Size(232, 32);
            this.cbox餐廳.TabIndex = 27;
            this.cbox餐廳.SelectedIndexChanged += new System.EventHandler(this.cbox餐廳_SelectedIndexChanged);
            // 
            // btn刪除餐廳
            // 
            this.btn刪除餐廳.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btn刪除餐廳.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn刪除餐廳.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn刪除餐廳.Location = new System.Drawing.Point(364, 58);
            this.btn刪除餐廳.Name = "btn刪除餐廳";
            this.btn刪除餐廳.Size = new System.Drawing.Size(133, 39);
            this.btn刪除餐廳.TabIndex = 32;
            this.btn刪除餐廳.Text = "刪除餐廳";
            this.btn刪除餐廳.UseVisualStyleBackColor = false;
            this.btn刪除餐廳.Click += new System.EventHandler(this.btn刪除餐廳_Click);
            // 
            // btn新增餐廳
            // 
            this.btn新增餐廳.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btn新增餐廳.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn新增餐廳.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn新增餐廳.Location = new System.Drawing.Point(364, 104);
            this.btn新增餐廳.Name = "btn新增餐廳";
            this.btn新增餐廳.Size = new System.Drawing.Size(133, 40);
            this.btn新增餐廳.TabIndex = 34;
            this.btn新增餐廳.Text = "新增餐廳";
            this.btn新增餐廳.UseVisualStyleBackColor = false;
            this.btn新增餐廳.Click += new System.EventHandler(this.btn新增餐廳_Click);
            // 
            // cbox餐點
            // 
            this.cbox餐點.BackColor = System.Drawing.Color.White;
            this.cbox餐點.FormattingEnabled = true;
            this.cbox餐點.Location = new System.Drawing.Point(111, 120);
            this.cbox餐點.Name = "cbox餐點";
            this.cbox餐點.Size = new System.Drawing.Size(234, 32);
            this.cbox餐點.TabIndex = 27;
            this.cbox餐點.SelectedIndexChanged += new System.EventHandler(this.cbox餐點_SelectedIndexChanged);
            // 
            // btn刪除餐點
            // 
            this.btn刪除餐點.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn刪除餐點.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn刪除餐點.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn刪除餐點.Location = new System.Drawing.Point(399, 40);
            this.btn刪除餐點.Name = "btn刪除餐點";
            this.btn刪除餐點.Size = new System.Drawing.Size(160, 37);
            this.btn刪除餐點.TabIndex = 32;
            this.btn刪除餐點.Text = "刪除餐點";
            this.btn刪除餐點.UseVisualStyleBackColor = false;
            this.btn刪除餐點.Click += new System.EventHandler(this.btn刪除餐點_Click);
            // 
            // btn新增餐點
            // 
            this.btn新增餐點.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn新增餐點.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn新增餐點.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn新增餐點.Location = new System.Drawing.Point(399, 86);
            this.btn新增餐點.Name = "btn新增餐點";
            this.btn新增餐點.Size = new System.Drawing.Size(160, 39);
            this.btn新增餐點.TabIndex = 34;
            this.btn新增餐點.Text = "新增餐點";
            this.btn新增餐點.UseVisualStyleBackColor = false;
            this.btn新增餐點.Click += new System.EventHandler(this.btn新增餐點_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.btn修改餐點);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.btn刪除餐點);
            this.groupBox3.Controls.Add(this.cbox餐點分類);
            this.groupBox3.Controls.Add(this.nud餐點價格);
            this.groupBox3.Controls.Add(this.btn修改餐點資料);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.txt餐點名稱);
            this.groupBox3.Controls.Add(this.btn新增餐點);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox3.Location = new System.Drawing.Point(12, 356);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(765, 202);
            this.groupBox3.TabIndex = 45;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "餐點資料";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // btn修改餐點
            // 
            this.btn修改餐點.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn修改餐點.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn修改餐點.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn修改餐點.Location = new System.Drawing.Point(399, 143);
            this.btn修改餐點.Name = "btn修改餐點";
            this.btn修改餐點.Size = new System.Drawing.Size(160, 39);
            this.btn修改餐點.TabIndex = 44;
            this.btn修改餐點.Text = "修改餐點";
            this.btn修改餐點.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(10, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 37);
            this.label1.TabIndex = 43;
            this.label1.Text = "分類";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbox餐點分類
            // 
            this.cbox餐點分類.BackColor = System.Drawing.Color.White;
            this.cbox餐點分類.FormattingEnabled = true;
            this.cbox餐點分類.Location = new System.Drawing.Point(131, 38);
            this.cbox餐點分類.Name = "cbox餐點分類";
            this.cbox餐點分類.Size = new System.Drawing.Size(202, 32);
            this.cbox餐點分類.TabIndex = 42;
            this.cbox餐點分類.SelectedIndexChanged += new System.EventHandler(this.cbox餐點分類_SelectedIndexChanged);
            // 
            // nud餐點價格
            // 
            this.nud餐點價格.BackColor = System.Drawing.Color.White;
            this.nud餐點價格.Location = new System.Drawing.Point(131, 143);
            this.nud餐點價格.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud餐點價格.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud餐點價格.Name = "nud餐點價格";
            this.nud餐點價格.Size = new System.Drawing.Size(202, 33);
            this.nud餐點價格.TabIndex = 40;
            this.nud餐點價格.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud餐點價格.Value = new decimal(new int[] {
            60,
            0,
            0,
            0});
            // 
            // btn修改餐點資料
            // 
            this.btn修改餐點資料.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn修改餐點資料.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn修改餐點資料.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn修改餐點資料.Location = new System.Drawing.Point(10, 374);
            this.btn修改餐點資料.Name = "btn修改餐點資料";
            this.btn修改餐點資料.Size = new System.Drawing.Size(249, 48);
            this.btn修改餐點資料.TabIndex = 39;
            this.btn修改餐點資料.Text = "修改餐點資料";
            this.btn修改餐點資料.UseVisualStyleBackColor = false;
            this.btn修改餐點資料.Click += new System.EventHandler(this.btn修改餐點資料_Click);
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(21, 143);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 30);
            this.label5.TabIndex = 38;
            this.label5.Text = "餐點價格";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txt餐點名稱
            // 
            this.txt餐點名稱.BackColor = System.Drawing.Color.White;
            this.txt餐點名稱.Location = new System.Drawing.Point(131, 86);
            this.txt餐點名稱.Name = "txt餐點名稱";
            this.txt餐點名稱.Size = new System.Drawing.Size(202, 33);
            this.txt餐點名稱.TabIndex = 37;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(10, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 30);
            this.label4.TabIndex = 36;
            this.label4.Text = "餐點";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbox餐點圖
            // 
            this.pbox餐點圖.Image = global::WindowsFormsAppBaby.Properties.Resources.歡迎光臨;
            this.pbox餐點圖.Location = new System.Drawing.Point(514, 59);
            this.pbox餐點圖.Name = "pbox餐點圖";
            this.pbox餐點圖.Size = new System.Drawing.Size(263, 160);
            this.pbox餐點圖.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox餐點圖.TabIndex = 45;
            this.pbox餐點圖.TabStop = false;
            // 
            // btn上傳圖片
            // 
            this.btn上傳圖片.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btn上傳圖片.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn上傳圖片.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn上傳圖片.Location = new System.Drawing.Point(651, 248);
            this.btn上傳圖片.Name = "btn上傳圖片";
            this.btn上傳圖片.Size = new System.Drawing.Size(126, 39);
            this.btn上傳圖片.TabIndex = 44;
            this.btn上傳圖片.Text = "上傳圖片";
            this.btn上傳圖片.UseVisualStyleBackColor = false;
            this.btn上傳圖片.Click += new System.EventHandler(this.btn上傳圖片_Click);
            // 
            // btn修改餐廳資料
            // 
            this.btn修改餐廳資料.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btn修改餐廳資料.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn修改餐廳資料.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn修改餐廳資料.Location = new System.Drawing.Point(364, 150);
            this.btn修改餐廳資料.Name = "btn修改餐廳資料";
            this.btn修改餐廳資料.Size = new System.Drawing.Size(133, 40);
            this.btn修改餐廳資料.TabIndex = 47;
            this.btn修改餐廳資料.Text = "修改餐廳資料";
            this.btn修改餐廳資料.UseVisualStyleBackColor = false;
            this.btn修改餐廳資料.Click += new System.EventHandler(this.btn修改餐廳資料_Click);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Blue;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(-4, -1);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(806, 47);
            this.label3.TabIndex = 46;
            this.label3.Text = "<全端便當訂購系統>";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(6, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 39);
            this.label2.TabIndex = 48;
            this.label2.Text = "餐廳:";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("微軟正黑體", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(6, 120);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 39);
            this.label6.TabIndex = 49;
            this.label6.Text = "菜單:";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("微軟正黑體", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(6, 180);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(143, 39);
            this.label7.TabIndex = 50;
            this.label7.Text = "餐廳名稱:";
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("微軟正黑體", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(6, 228);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(143, 39);
            this.label8.TabIndex = 51;
            this.label8.Text = "餐廳電話:";
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("微軟正黑體", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label9.Location = new System.Drawing.Point(6, 279);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(143, 39);
            this.label9.TabIndex = 52;
            this.label9.Text = "餐廳地址:";
            // 
            // txt餐廳名稱
            // 
            this.txt餐廳名稱.BackColor = System.Drawing.Color.White;
            this.txt餐廳名稱.Location = new System.Drawing.Point(143, 180);
            this.txt餐廳名稱.Name = "txt餐廳名稱";
            this.txt餐廳名稱.Size = new System.Drawing.Size(202, 33);
            this.txt餐廳名稱.TabIndex = 45;
            // 
            // txt餐廳電話
            // 
            this.txt餐廳電話.BackColor = System.Drawing.Color.White;
            this.txt餐廳電話.Location = new System.Drawing.Point(143, 228);
            this.txt餐廳電話.Name = "txt餐廳電話";
            this.txt餐廳電話.Size = new System.Drawing.Size(202, 33);
            this.txt餐廳電話.TabIndex = 53;
            // 
            // txt餐廳地址
            // 
            this.txt餐廳地址.BackColor = System.Drawing.Color.White;
            this.txt餐廳地址.Location = new System.Drawing.Point(143, 282);
            this.txt餐廳地址.Name = "txt餐廳地址";
            this.txt餐廳地址.Size = new System.Drawing.Size(202, 33);
            this.txt餐廳地址.TabIndex = 54;
            // 
            // Form餐點管理
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(801, 585);
            this.Controls.Add(this.txt餐廳地址);
            this.Controls.Add(this.txt餐廳電話);
            this.Controls.Add(this.txt餐廳名稱);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cbox餐點);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn刪除餐廳);
            this.Controls.Add(this.cbox餐廳);
            this.Controls.Add(this.pbox餐點圖);
            this.Controls.Add(this.btn修改餐廳資料);
            this.Controls.Add(this.btn上傳圖片);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.btn新增餐廳);
            this.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Form餐點管理";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "全端點餐系統";
            this.Load += new System.EventHandler(this.Form餐點管理_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud餐點價格)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox餐點圖)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox cbox餐廳;
        private System.Windows.Forms.Button btn刪除餐廳;
        private System.Windows.Forms.Button btn新增餐廳;
        private System.Windows.Forms.ComboBox cbox餐點;
        private System.Windows.Forms.Button btn刪除餐點;
        private System.Windows.Forms.Button btn新增餐點;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btn修改餐點資料;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt餐點名稱;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn上傳圖片;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbox餐點分類;
        private System.Windows.Forms.NumericUpDown nud餐點價格;
        private System.Windows.Forms.PictureBox pbox餐點圖;
        private System.Windows.Forms.Button btn修改餐廳資料;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btn修改餐點;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt餐廳名稱;
        private System.Windows.Forms.TextBox txt餐廳電話;
        private System.Windows.Forms.TextBox txt餐廳地址;
    }
}