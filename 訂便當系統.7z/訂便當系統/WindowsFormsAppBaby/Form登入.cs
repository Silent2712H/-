﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsAppBaby.Entity;
using WindowsFormsAppBaby.Factory;

namespace WindowsFormsAppBaby
{
    public partial class Form登入 : Form
    {
        List<s訂購班級> listclass = new List<s訂購班級>();
        s訂購班級 orderclass;
        public void read讀取訂購單位()
        {
            listclass = (new s訂購班級Factory()).queryAll訂購單位();
            
            if (listclass != null)
            {
                foreach (s訂購班級 item in listclass)
                {
                    cbox訂購單位.Items.Add(item.f訂購單位);
                }
                
                GlobalVar.listGlobalOrg = listclass;
            }
        }

      
        List<s訂購人> listPerson = new List<s訂購人>();     
        s訂購人 值日生;        
        s訂購人 非值日生;
        
        public void read讀取訂購人(int fId)
        {
           
            listPerson = (new s訂購人Factory()).query單位訂購人(fId);


            值日生 = null;
            非值日生 = null;         
            cbox訂購人.Items.Clear();
            cbox訂購人.Text = "";
            lbl值日生.Text = "";
            txt密碼.Text = "";

            if (listPerson != null)
            {
                foreach (s訂購人 item in listPerson)
                {
                    cbox訂購人.Items.Add($"{item.f姓名}[{item.fId}]");
                }

                cbox訂購人.SelectedIndex = 0;;


                值日生 = (new s訂購人Factory()).query單位值日生(fId);
                if (值日生 != null)
                {
                    lbl值日生.Text = $"{值日生.f姓名}[{值日生.fId}]";
                }
            }
            else
            {
                listPerson = new List<s訂購人>();
            }
        }

        public Form登入()
        {
            InitializeComponent();
        }

        private void Form登入_Load(object sender, EventArgs e)
        {
            
            this.Text = GlobalVar.version版本;


            listclass.Clear();
            orderclass = null;
            listPerson.Clear();
            值日生 = null;
            非值日生 = null;          
            cbox訂購單位.Items.Clear();
            cbox訂購人.Items.Clear();
            lbl值日生.Text = "";
            txt密碼.Text = "";
            txt系統訊息.Text = "歡迎使用本系統";

          
            read讀取訂購單位();
            if (listclass != null)
            {
                cbox訂購單位.SelectedIndex = 0;
            }
        }

        private void cbox訂購單位_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbox訂購單位.SelectedIndex > -1)
            {
                orderclass = listclass[cbox訂購單位.SelectedIndex];

                read讀取訂購人(orderclass.fId);
            }
        }

        private void cbox訂購人_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbox訂購人.SelectedIndex > -1)
            {
                非值日生 = listPerson[cbox訂購人.SelectedIndex];
            }
        }

        private void btn登入_Click(object sender, EventArgs e)
        {
            if (非值日生 != null)
            {
                if (txt密碼.Text == 非值日生.f密碼)
                {
                    GlobalOrder.e目前訂購單位 = orderclass;
                    GlobalOrder.e目前訂購人 = 非值日生;

                    this.Close();
                }
                else
                {
                    txt系統訊息.Text = "密碼錯誤！";
                }
            }
            else
            {
                txt系統訊息.Text = "尚未選取訂購人！";
            }
        }

        private void txt密碼_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                btn登入.Focus();
                btn登入_Click(sender, e);
                txt密碼.Focus();
            }
        }
    }
}
