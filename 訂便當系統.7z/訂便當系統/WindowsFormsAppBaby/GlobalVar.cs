﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsAppBaby.Entity;
using WindowsFormsAppBaby.Factory;

namespace WindowsFormsAppBaby
{
    class GlobalVar
    {
        //public static string sqlstring = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\iii\Desktop\WindowsForms10-23\WindowsFormsAppBaby\myfuckdb.mdf;Integrated Security=True";
        public static string sqlstring = @"Data Source=.;Initial Catalog=LocakDataBase;Integrated Security=True";

        public static string image分類圖檔相對路徑 = @"category\";

        public static string image菜單圖檔相對路徑 = @"menu\";     
        public static string image菜單圖檔絕對路徑 = System.IO.Directory.GetCurrentDirectory() + @"\menu\";

        public static string version版本 = @"全端訂購系統";
     
        public static List<s訂購班級> listGlobalOrg = new List<s訂購班級>();      
        public static s餐廳 store目前餐廳資訊;
    }
}
