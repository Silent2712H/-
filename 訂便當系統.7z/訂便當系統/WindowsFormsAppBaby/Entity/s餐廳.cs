﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsAppBaby.Entity
{
    class s餐廳
    {
        public int fId { get; set; }
        public string f餐廳名稱 { get; set; }
        public string f餐廳電話 { get; set; }
        public string f餐廳地址 { get; set; }
    }
}