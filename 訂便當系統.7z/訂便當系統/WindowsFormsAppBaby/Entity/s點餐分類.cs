﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsAppBaby.Entity
{
    class s點餐分類
    {
        public int fId { get; set; }
        public string f分類 { get; set; }
        public string f圖片 { get; set; }
    }
}
