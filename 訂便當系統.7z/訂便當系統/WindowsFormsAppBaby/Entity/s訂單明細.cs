﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsAppBaby.Entity
{
    class s訂單明細
    {
        public int fId { get; set; }
        public int f訂單Id { get; set; }

        public int f訂購人Id { get; set; }
        public int f餐點Id { get; set; }
        public int f數量 { get; set; }
        public int a單位Id { get; set; }
        public int a餐廳Id { get; set; }
        public int indexIn總訂單 { get; set; }
    }
}
