﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsAppBaby.Entity
{
    class s訂單
    {
        public int fId { get; set; }
        public DateTime f訂單時間 { get; set; }
    }
}
