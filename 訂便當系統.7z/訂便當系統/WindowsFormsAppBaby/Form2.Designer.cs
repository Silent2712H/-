﻿namespace WindowsFormsAppBaby
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.cbox訂購單位 = new System.Windows.Forms.ComboBox();
            this.cbox訂購人 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btn資料篩選 = new System.Windows.Forms.Button();
            this.cbox餐廳 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lbl總計 = new System.Windows.Forms.Label();
            this.btn移除訂單 = new System.Windows.Forms.Button();
            this.btn全部清空 = new System.Windows.Forms.Button();
            this.btn重置篩選 = new System.Windows.Forms.Button();
            this.btn另存訂單 = new System.Windows.Forms.Button();
            this.lbox訂單列表 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(12, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 36);
            this.label2.TabIndex = 1;
            this.label2.Text = "訂購班級:";
            // 
            // cbox訂購單位
            // 
            this.cbox訂購單位.FormattingEnabled = true;
            this.cbox訂購單位.Location = new System.Drawing.Point(152, 78);
            this.cbox訂購單位.Name = "cbox訂購單位";
            this.cbox訂購單位.Size = new System.Drawing.Size(200, 39);
            this.cbox訂購單位.TabIndex = 2;
            this.cbox訂購單位.SelectedIndexChanged += new System.EventHandler(this.cbox訂購單位_SelectedIndexChanged);
            // 
            // cbox訂購人
            // 
            this.cbox訂購人.FormattingEnabled = true;
            this.cbox訂購人.Location = new System.Drawing.Point(151, 133);
            this.cbox訂購人.Name = "cbox訂購人";
            this.cbox訂購人.Size = new System.Drawing.Size(201, 39);
            this.cbox訂購人.TabIndex = 4;
            this.cbox訂購人.SelectedIndexChanged += new System.EventHandler(this.cbox訂購人_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(12, 133);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 36);
            this.label3.TabIndex = 3;
            this.label3.Text = "訂購人:";
            // 
            // btn資料篩選
            // 
            this.btn資料篩選.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btn資料篩選.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn資料篩選.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn資料篩選.Location = new System.Drawing.Point(593, 233);
            this.btn資料篩選.Name = "btn資料篩選";
            this.btn資料篩選.Size = new System.Drawing.Size(139, 57);
            this.btn資料篩選.TabIndex = 8;
            this.btn資料篩選.Text = "菜單篩選";
            this.btn資料篩選.UseVisualStyleBackColor = false;
            this.btn資料篩選.Click += new System.EventHandler(this.btn資料篩選_Click);
            // 
            // cbox餐廳
            // 
            this.cbox餐廳.FormattingEnabled = true;
            this.cbox餐廳.Location = new System.Drawing.Point(492, 75);
            this.cbox餐廳.Name = "cbox餐廳";
            this.cbox餐廳.Size = new System.Drawing.Size(217, 39);
            this.cbox餐廳.TabIndex = 6;
            this.cbox餐廳.SelectedIndexChanged += new System.EventHandler(this.cbox餐廳_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(405, 78);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 36);
            this.label4.TabIndex = 5;
            this.label4.Text = "餐廳";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(12, 558);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 36);
            this.label5.TabIndex = 5;
            this.label5.Text = "總計:";
            // 
            // lbl總計
            // 
            this.lbl總計.BackColor = System.Drawing.Color.White;
            this.lbl總計.Font = new System.Drawing.Font("微軟正黑體", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl總計.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl總計.Location = new System.Drawing.Point(96, 558);
            this.lbl總計.Name = "lbl總計";
            this.lbl總計.Size = new System.Drawing.Size(160, 42);
            this.lbl總計.TabIndex = 6;
            this.lbl總計.Text = "XX 元";
            this.lbl總計.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn移除訂單
            // 
            this.btn移除訂單.BackColor = System.Drawing.Color.Navy;
            this.btn移除訂單.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn移除訂單.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn移除訂單.Location = new System.Drawing.Point(254, 429);
            this.btn移除訂單.Name = "btn移除訂單";
            this.btn移除訂單.Size = new System.Drawing.Size(152, 45);
            this.btn移除訂單.TabIndex = 7;
            this.btn移除訂單.Text = "移除訂單";
            this.btn移除訂單.UseVisualStyleBackColor = false;
            this.btn移除訂單.Click += new System.EventHandler(this.btn移除訂單_Click);
            // 
            // btn全部清空
            // 
            this.btn全部清空.BackColor = System.Drawing.Color.Navy;
            this.btn全部清空.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn全部清空.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn全部清空.Location = new System.Drawing.Point(424, 429);
            this.btn全部清空.Name = "btn全部清空";
            this.btn全部清空.Size = new System.Drawing.Size(160, 45);
            this.btn全部清空.TabIndex = 8;
            this.btn全部清空.Text = "全部移除";
            this.btn全部清空.UseVisualStyleBackColor = false;
            this.btn全部清空.Click += new System.EventHandler(this.btn全部清空_Click);
            // 
            // btn重置篩選
            // 
            this.btn重置篩選.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btn重置篩選.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn重置篩選.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn重置篩選.Location = new System.Drawing.Point(590, 325);
            this.btn重置篩選.Name = "btn重置篩選";
            this.btn重置篩選.Size = new System.Drawing.Size(142, 54);
            this.btn重置篩選.TabIndex = 8;
            this.btn重置篩選.Text = "重置篩選";
            this.btn重置篩選.UseVisualStyleBackColor = false;
            this.btn重置篩選.Click += new System.EventHandler(this.btn重置篩選_Click);
            // 
            // btn另存訂單
            // 
            this.btn另存訂單.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btn另存訂單.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn另存訂單.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn另存訂單.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn另存訂單.Location = new System.Drawing.Point(567, 547);
            this.btn另存訂單.Name = "btn另存訂單";
            this.btn另存訂單.Size = new System.Drawing.Size(142, 53);
            this.btn另存訂單.TabIndex = 11;
            this.btn另存訂單.Text = "送出訂單";
            this.btn另存訂單.UseVisualStyleBackColor = false;
            this.btn另存訂單.Click += new System.EventHandler(this.btn另存訂單_Click);
            // 
            // lbox訂單列表
            // 
            this.lbox訂單列表.BackColor = System.Drawing.Color.AliceBlue;
            this.lbox訂單列表.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbox訂單列表.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lbox訂單列表.FormattingEnabled = true;
            this.lbox訂單列表.ItemHeight = 25;
            this.lbox訂單列表.Location = new System.Drawing.Point(17, 233);
            this.lbox訂單列表.Name = "lbox訂單列表";
            this.lbox訂單列表.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lbox訂單列表.Size = new System.Drawing.Size(567, 179);
            this.lbox訂單列表.TabIndex = 4;
            this.lbox訂單列表.SelectedIndexChanged += new System.EventHandler(this.lbox訂單列表_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Blue;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(-1, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(744, 47);
            this.label1.TabIndex = 38;
            this.label1.Text = "<全端便當訂購系統>";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(744, 616);
            this.Controls.Add(this.cbox餐廳);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cbox訂購人);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cbox訂購單位);
            this.Controls.Add(this.btn另存訂單);
            this.Controls.Add(this.btn資料篩選);
            this.Controls.Add(this.btn重置篩選);
            this.Controls.Add(this.btn全部清空);
            this.Controls.Add(this.btn移除訂單);
            this.Controls.Add(this.lbl總計);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lbox訂單列表);
            this.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "全端點餐系統";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbox訂購單位;
        private System.Windows.Forms.ComboBox cbox訂購人;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbox餐廳;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbl總計;
        private System.Windows.Forms.Button btn移除訂單;
        private System.Windows.Forms.Button btn全部清空;
        private System.Windows.Forms.Button btn資料篩選;
        private System.Windows.Forms.Button btn重置篩選;
        private System.Windows.Forms.Button btn另存訂單;
        private System.Windows.Forms.ListBox lbox訂單列表;
        private System.Windows.Forms.Label label1;
    }
}