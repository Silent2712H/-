﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsAppBaby.Entity;
using WindowsFormsAppBaby.Factory;

namespace WindowsFormsAppBaby
{
    public partial class Form餐點管理 : Form
    { 
        List<s點餐分類> list點餐分類 = new List<s點餐分類>();
        List<int> listID;
        s點餐分類 菜單分類;
        void listview顯示點餐分類()
        {

            list點餐分類.Clear();
            菜單分類 = null;
            cbox餐點分類.Items.Clear();

            list點餐分類 = (new s點餐分類Factory()).queryAll點餐分類();
            
            if (list點餐分類 != null)
            {
              
                listID = list點餐分類.Select(c => c.fId).ToList();

                foreach (s點餐分類 item in list點餐分類)
                {
                    cbox餐點分類.Items.Add(item.f分類);
                }
                cbox餐點分類.SelectedIndex = 0;
            }
        }

      
        List<s餐廳> list所有餐廳 = new List<s餐廳>();
        s餐廳 currentRest;

        void 讀取餐廳()
        {
            list所有餐廳.Clear();
            currentRest = null;
            cbox餐廳.Items.Clear();
            cbox餐廳.Text = "";
            txt餐廳名稱.Text = "";
            txt餐廳電話.Text = "";
            txt餐廳地址.Text = "";

            list所有餐廳 = (new s餐廳Factory()).queryAll餐廳();

            if (list所有餐廳 != null)
            {
                foreach (s餐廳 item in list所有餐廳)
                {
                    cbox餐廳.Items.Add(item.f餐廳名稱);
                }
                cbox餐廳.SelectedIndex = 0;

                對應餐點(currentRest.fId);
            }
            else
            {
                list所有餐廳 = new List<s餐廳>();
            }
        }

  
        List<s餐點> list餐廳對應餐點 = new List<s餐點>();
        s餐點 class目前餐點;
        string image圖檔名稱;
        FileStream fs;
  
        void 對應餐點(int f餐廳Id)
        {     
            list餐廳對應餐點.Clear();
            class目前餐點 = null;
            cbox餐點.Items.Clear();
            cbox餐點.Text = "";
            if (list點餐分類 != null)
            {
                cbox餐點分類.SelectedIndex = 0;
            }
            txt餐點名稱.Text = "";
            nud餐點價格.Value = 60;
            image圖檔名稱 = "";
            pbox餐點圖.Image = Image.FromFile(GlobalVar.image菜單圖檔相對路徑 + @"default.png");

            list餐廳對應餐點 = (new s餐點Factory()).queryBy餐廳(f餐廳Id);

            if (list餐廳對應餐點 != null)
            {
                foreach (s餐點 item in list餐廳對應餐點)
                {
                    cbox餐點.Items.Add(item.f餐點);
                }
                cbox餐點.SelectedIndex = 0;
            }
            else
            {
                list餐廳對應餐點 = new List<s餐點>();
            }
        }

        public Form餐點管理()
        {
            InitializeComponent();
        }

        private void Form餐點管理_Load(object sender, EventArgs e)
        {
            this.Text = GlobalVar.version版本;

            listview顯示點餐分類();

            重置();
        }

        void 重置()
        {
            讀取餐廳();
        }

        private void cbox餐點分類_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbox餐點分類.SelectedIndex > -1)
            {
                菜單分類 = list點餐分類[cbox餐點分類.SelectedIndex];
            }
        }

        private void cbox餐廳_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbox餐廳.SelectedIndex > -1)
            {
                currentRest = list所有餐廳[cbox餐廳.SelectedIndex];

                txt餐廳名稱.Text = currentRest.f餐廳名稱;
                txt餐廳電話.Text = currentRest.f餐廳電話;
                txt餐廳地址.Text = currentRest.f餐廳地址;

                對應餐點(currentRest.fId);
            }
        }

        private void cbox餐點_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbox餐點.SelectedIndex > -1)
            {
                class目前餐點 = list餐廳對應餐點[cbox餐點.SelectedIndex];

                if (list點餐分類 != null)
                {
                    int index分類 = listID.IndexOf(class目前餐點.f分類Id);
                    if (index分類 > -1)
                    {
                        cbox餐點分類.SelectedIndex = index分類;
                    }
                }

                txt餐點名稱.Text = class目前餐點.f餐點;
                nud餐點價格.Value = class目前餐點.f價格;

                try
                {
                    fs = new FileStream(GlobalVar.image菜單圖檔絕對路徑 + class目前餐點.f圖片, FileMode.Open, FileAccess.Read);
                    pbox餐點圖.Image = System.Drawing.Image.FromStream(fs);
                    fs.Close();
                }
                catch
                {
                    pbox餐點圖.Image = Image.FromFile(GlobalVar.image菜單圖檔相對路徑 + @"default.png");
                }
            }
        }

        private void btn刪除餐廳_Click(object sender, EventArgs e)
        {
            if (cbox餐廳.SelectedIndex != -1)
            {
                DialogResult R = MessageBox.Show("確定要刪除？(餐點會一併刪除哦！)", "刪除確認", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (R == DialogResult.Yes)
                {
                    s餐廳 del餐廳 = (new s餐廳Factory()).query餐廳(list所有餐廳[cbox餐廳.SelectedIndex].fId);
                    if (del餐廳 != null)
                    {
                        List<s餐點> list刪除餐點 = (new s餐點Factory()).queryBy餐廳(del餐廳.fId);

                        foreach (s餐點 item in list刪除餐點)
                        {
                            if (!string.IsNullOrEmpty(item.f圖片))
                            {
                                try
                                {
                                    string str目前路徑 = GlobalVar.image菜單圖檔絕對路徑 + item.f圖片;
                                    if (System.IO.File.Exists(str目前路徑))
                                    {
                                        System.IO.File.Delete(str目前路徑);
                                    }
                                }
                                catch
                                {
                                    // 不刪除
                                }
                            }
                        }

                        (new s餐廳Factory()).delete(del餐廳);
                    }

                    重置();
                    MessageBox.Show("刪除成功！");
                }
                else
                {
                    // 不刪除
                }
            }
        }

        private void btn刪除餐點_Click(object sender, EventArgs e)
        {
            if (cbox餐點.SelectedIndex != -1)
            {
                DialogResult R = MessageBox.Show("確定要刪除？", "刪除確認", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (R == DialogResult.Yes)
                {
                    s餐點 del餐點 = (new s餐點Factory()).queryById(list餐廳對應餐點[cbox餐點.SelectedIndex].fId);
                    if (del餐點 != null)
                    {
                        if (!string.IsNullOrEmpty(del餐點.f圖片))
                        {
                            try
                            {
                                string str目前路徑 = GlobalVar.image菜單圖檔絕對路徑 + del餐點.f圖片;
                                if (System.IO.File.Exists(str目前路徑))
                                {
                                    System.IO.File.Delete(str目前路徑);
                                }
                            }
                            catch
                            {
                                // 不刪除
                            }
                        }

                        (new s餐點Factory()).delete(del餐點);
                    }

                    重置();
                    MessageBox.Show("刪除成功！");
                }
                else
                {
                    // 不刪除
                }
            }
        }

        private void btn新增餐廳_Click(object sender, EventArgs e)
        {
            if ((txt餐廳名稱.Text != "") && (txt餐廳電話.Text != "") && (txt餐廳地址.Text != ""))
            {
                DialogResult R = MessageBox.Show("確定要新增？", "新增確認", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (R == DialogResult.Yes)
                {
                    s餐廳 new餐廳 = new s餐廳();
                    new餐廳.f餐廳名稱 = txt餐廳名稱.Text;
                    new餐廳.f餐廳電話 = txt餐廳電話.Text;
                    new餐廳.f餐廳地址 = txt餐廳地址.Text;
                    (new s餐廳Factory()).create(new餐廳);

                    重置();
                    MessageBox.Show("新增成功！");
                }
                else
                {
                    // 不新增
                }
            }
        }

        private void btn修改餐廳資料_Click(object sender, EventArgs e)
        {
            if ( (cbox餐廳.SelectedIndex > -1) && (txt餐廳名稱.Text != "") && (txt餐廳電話.Text != "") && (txt餐廳地址.Text != ""))
            {
                DialogResult R = MessageBox.Show("確定要修改？", "修改確認", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (R == DialogResult.Yes)
                {
                    s餐廳 new餐廳 = new s餐廳();
                    new餐廳.fId = list所有餐廳[cbox餐廳.SelectedIndex].fId;
                    new餐廳.f餐廳名稱 = txt餐廳名稱.Text;
                    new餐廳.f餐廳電話 = txt餐廳電話.Text;
                    new餐廳.f餐廳地址 = txt餐廳地址.Text;
                    (new s餐廳Factory()).update(new餐廳);

                    重置();
                    MessageBox.Show("修改成功！");
                }
                else
                {
                    // 不修改
                }
            }
        }

        private void btn上傳圖片_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "圖檔類型 (*.jpg, *.jpeg, *.png)|*.jpg;*.jpeg;*.png";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                 
                    pbox餐點圖.Image = Image.FromFile(ofd.FileName);
                 
                    string fileExt = Path.GetExtension(ofd.SafeFileName);

                    image圖檔名稱 = fileExt;
                }
                catch
                {
                    image圖檔名稱 = "";
                    pbox餐點圖.Image = Image.FromFile(GlobalVar.image菜單圖檔相對路徑 + @"default.png");
                }
            }
        }

        private void btn新增餐點_Click(object sender, EventArgs e)
        {
            if ((cbox餐廳.SelectedIndex > -1) && (cbox餐點分類.SelectedIndex > -1) && (txt餐點名稱.Text != ""))
            {
              
                DialogResult R = MessageBox.Show("確定要新增？", "新增確認", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (R == DialogResult.Yes)
                {
                    s餐點 new餐點 = new s餐點();
                    new餐點.f分類Id = 菜單分類.fId;
                    new餐點.f餐廳Id = currentRest.fId;
                    new餐點.f餐點 = txt餐點名稱.Text;
                    new餐點.f價格 = Convert.ToInt32(nud餐點價格.Value);
                    
                    if (!string.IsNullOrEmpty(image圖檔名稱))
                    {
                       
                        List<s餐點> list = (new s餐點Factory()).queryBy點餐分類(菜單分類.fId, currentRest.fId);
                        if (list == null)
                        {
                            image圖檔名稱 = $"{菜單分類.fId:00}{currentRest.fId:000}0001" + image圖檔名稱;
                        }
                        else
                        {
                            image圖檔名稱 = $"{菜單分類.fId:00}{currentRest.fId:000}{list.Count + 1:0000}" + image圖檔名稱;
                        }                        
                        try
                        {
                            pbox餐點圖.Image.Save(GlobalVar.image菜單圖檔相對路徑 + image圖檔名稱);
                        }
                        catch
                        {
                            image圖檔名稱 = "default.png";
                        }
                    }
                    else
                    {
                        image圖檔名稱 = "default.png";
                    }
                    new餐點.f圖片 = image圖檔名稱;

                    (new s餐點Factory()).create(new餐點);

                    重置();
                    MessageBox.Show("新增成功！");
                }
                else
                {
                    // 不新增
                }
            }
        }

        private void btn修改餐點資料_Click(object sender, EventArgs e)
        {
            if ( (cbox餐廳.SelectedIndex > -1) && (cbox餐點.SelectedIndex > -1) && (cbox餐點分類.SelectedIndex > -1) && (txt餐點名稱.Text != "") )
            {
              
                DialogResult R = MessageBox.Show("確定要修改？", "修改確認", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (R == DialogResult.Yes)
                {
                    s餐點 new餐點 = new s餐點();
                    new餐點.fId = class目前餐點.fId;
                    new餐點.f分類Id = 菜單分類.fId;
                    new餐點.f餐廳Id = currentRest.fId;
                    new餐點.f餐點 = txt餐點名稱.Text;
                    new餐點.f價格 = Convert.ToInt32(nud餐點價格.Value);

                    image圖檔名稱 = class目前餐點.f圖片;
                    new餐點.f圖片 = image圖檔名稱;

                    if (!string.IsNullOrEmpty(image圖檔名稱))
                    {
                        try
                        {
                            string str目前路徑 = GlobalVar.image菜單圖檔絕對路徑 + image圖檔名稱;

                            if (System.IO.File.Exists(str目前路徑))
                            {
                                System.IO.File.Delete(str目前路徑);
                            }

                            pbox餐點圖.Image.Save(GlobalVar.image菜單圖檔相對路徑 + image圖檔名稱);
                        }
                        catch
                        {
                            // 不變更
                        }
                    }
                    (new s餐點Factory()).update(new餐點);

                    重置();
                    MessageBox.Show("修改成功！");
                }
                else
                {
                    // 不修改
                }
            }
        }

        private void txt餐廳名稱_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }
    }
}