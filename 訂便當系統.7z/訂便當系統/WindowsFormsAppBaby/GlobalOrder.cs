﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsAppBaby.Entity;
using WindowsFormsAppBaby.Factory;

namespace WindowsFormsAppBaby
{
    class GlobalOrder
    {
        public static s訂購班級 e目前訂購單位;
        public static s訂購人 e目前訂購人;

        public static List<s訂單明細> list訂單明細 = new List<s訂單明細>();
        public static List<s訂單明細> list我的最愛 = new List<s訂單明細>();
    }
}
