﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsAppBaby.Entity;
using WindowsFormsAppBaby.Factory;

namespace WindowsFormsAppBaby
{
    public partial class Form2 : Form
    {
       
        List<s訂單明細> list訂單明細Now = new List<s訂單明細>();
        List<s訂購班級> list所有訂購單位 = new List<s訂購班級>();
        List<s訂購人> list目前單位訂購人 = new List<s訂購人>();
        List<s餐廳> list所有餐廳 = new List<s餐廳>();
        List<s訂單明細> list搜尋訂單明細 = new List<s訂單明細>();
        bool 判斷是否為管理員;
        bool 判斷是否搜索到班級;
        bool 判斷是否搜索到餐廳;
        int int搜尋訂購單位Id;
        int int搜尋訂購人Id;
        int int搜尋餐廳Id;

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            this.Text = GlobalVar.version版本;

            if (GlobalOrder.e目前訂購人.fId == 0)
                判斷是否為管理員 = true;
            else
                判斷是否為管理員 = false;

            重置訂單(GlobalOrder.e目前訂購人.f值日生權限);
        }

        int total計算總價(List<s訂單明細> list訂單明細)
        {
            int int總價 = 0;
            if (list訂單明細.Count > 0)
            {
                s餐點 s餐;
                foreach (s訂單明細 item in list訂單明細)
                {
                    s餐 = (new s餐點Factory()).queryById(item.f餐點Id);
                    int總價 += item.f數量 * s餐.f價格;
                }
                lbl總計.Text = int總價.ToString() + " 元";
            }
            else
            {
                lbl總計.Text = "";
            }
            return int總價;
        }
        void 重置訂單(bool is有值日生權限)
        {
            list訂單明細Now.Clear();
            判斷是否搜索到班級 = false;
            判斷是否搜索到餐廳 = false;
            list所有訂購單位.Clear();
            list目前單位訂購人.Clear();
            list所有餐廳.Clear();
            list搜尋訂單明細.Clear();
            int搜尋訂購單位Id = -1;
            int搜尋訂購人Id = -1;
            int搜尋餐廳Id = -1;

            lbox訂單列表.Items.Clear();
            lbl總計.Text = "";
            cbox訂購單位.Items.Clear();
            cbox訂購人.Items.Clear();
            cbox餐廳.Items.Clear();
            cbox訂購單位.Text = "";
            cbox訂購人.Text = "";
            cbox餐廳.Text = "";
            cbox訂購單位.Enabled = true;
            cbox訂購人.Enabled = true;
            cbox餐廳.Enabled = true;
           

            if (is有值日生權限)
            {
               
                cbox訂購單位.Visible = true;
                cbox訂購人.Visible = true;
                cbox餐廳.Visible = true;
                btn資料篩選.Visible = true;
                btn重置篩選.Visible = true;
                btn另存訂單.Visible = true;

                if (GlobalOrder.list訂單明細.Count > 0)
                {
                    if (判斷是否為管理員)
                    {
                        s訂購班級 s班級;
                        s訂購人 s人;
                        s餐點 s餐;
                        s餐廳 s廳;
                        foreach (s訂單明細 item in GlobalOrder.list訂單明細)
                        {
                            s班級 = (new s訂購班級Factory()).query指定訂購單位Id(item.a單位Id);
                            s人 = (new s訂購人Factory()).query訂購人(item.f訂購人Id);
                            s餐 = (new s餐點Factory()).queryById(item.f餐點Id);
                            s廳 = (new s餐廳Factory()).query餐廳(item.a餐廳Id);

                            lbox訂單列表.Items.Add($"{s班級.f訂購單位} {s人.f姓名}[{s人.fId}]：{s廳.f餐廳名稱} {s餐.f餐點} {item.f數量}份 單價 {s餐.f價格} 元");
                        }
                        total計算總價(GlobalOrder.list訂單明細);
                    }
                    else
                    {
                        list訂單明細Now.Clear();
                        int i = 0;
                        s訂單明細 s;
                        foreach (s訂單明細 item in GlobalOrder.list訂單明細)
                        {
                            if (item.a單位Id == GlobalOrder.e目前訂購單位.fId)
                            {
                                s = new s訂單明細();
                                s.f訂購人Id = item.f訂購人Id;
                                s.f餐點Id = item.f餐點Id;
                                s.f數量 = item.f數量;
                                s.a單位Id = item.a單位Id;
                                s.a餐廳Id = item.a餐廳Id;
                                s.indexIn總訂單 = i;
                                list訂單明細Now.Add(s);
                            }
                            i++;
                        }

                        if (list訂單明細Now.Count > 0)
                        {
                            s訂購班級 s班級;
                            s訂購人 s人;
                            s餐點 s餐;
                            s餐廳 s廳;
                            foreach (s訂單明細 item in list訂單明細Now)
                            {
                                s班級 = (new s訂購班級Factory()).query指定訂購單位Id(item.a單位Id);
                                s人 = (new s訂購人Factory()).query訂購人(item.f訂購人Id);
                                s餐 = (new s餐點Factory()).queryById(item.f餐點Id);
                                s廳 = (new s餐廳Factory()).query餐廳(item.a餐廳Id);

                                lbox訂單列表.Items.Add($"{s班級.f訂購單位} {s人.f姓名}[{s人.fId}]：{s廳.f餐廳名稱} {s餐.f餐點} {item.f數量}份 單價 {s餐.f價格} 元");
                            }

                            total計算總價(list訂單明細Now);
                        }
                    }
                }

                搜索訂購班級();
                搜索所有餐廳();
            }
            else
            {
              
                cbox訂購單位.Visible = false;
                cbox訂購人.Visible = false;
                cbox餐廳.Visible = false;
                btn資料篩選.Visible = false;
                btn重置篩選.Visible = false;
                btn另存訂單.Visible = false;

                
                if (GlobalOrder.list訂單明細.Count > 0)
                {
                   
                    list訂單明細Now.Clear();
                    int i = 0;
                    foreach (s訂單明細 item in GlobalOrder.list訂單明細)
                    {
                        if (item.f訂購人Id == GlobalOrder.e目前訂購人.fId)
                        {
                            s訂單明細 s = new s訂單明細();
                            s.f訂購人Id = item.f訂購人Id;
                            s.f餐點Id = item.f餐點Id;
                            s.f數量 = item.f數量;
                            s.a單位Id = item.a單位Id;
                            s.a餐廳Id = item.a餐廳Id;
                            s.indexIn總訂單 = i;
                            list訂單明細Now.Add(s);
                        }
                        i++;
                    }

                    if (list訂單明細Now.Count > 0)
                    {
                        foreach (s訂單明細 item in list訂單明細Now)
                        {
                            s訂購班級 s班級 = (new s訂購班級Factory()).query指定訂購單位Id(item.a單位Id);
                            s訂購人 s人 = (new s訂購人Factory()).query訂購人(item.f訂購人Id);
                            s餐點 s餐 = (new s餐點Factory()).queryById(item.f餐點Id);
                            s餐廳 s廳 = (new s餐廳Factory()).query餐廳(item.a餐廳Id);

                            lbox訂單列表.Items.Add($"{s班級.f訂購單位} {s人.f姓名}[{s人.fId}]：{s廳.f餐廳名稱} {s餐.f餐點} {item.f數量}份 單價 {s餐.f價格} 元");
                        }
                        total計算總價(list訂單明細Now);
                    }
                }
            }
        }

        private void lbox訂單列表_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        


      
        private void btn餐廳排序_Click(object sender, EventArgs e)
        {

            重置訂單(GlobalOrder.e目前訂購人.f值日生權限);
        }

      
        void 搜索所有餐廳()
        {
            cbox餐廳.Items.Clear();
           
            if (GlobalOrder.e目前訂購人.f值日生權限)
            {              
                if (GlobalOrder.list訂單明細.Count > 0)
                {
                
                    if (判斷是否為管理員)
                    {                       
                        List<int> list餐廳id = GlobalOrder.list訂單明細.Select(order => order.a餐廳Id).Distinct().OrderBy(e => e).ToList();
                        list所有餐廳.Clear();
                        foreach (int id in list餐廳id)
                        {
                            list所有餐廳.Add((new s餐廳Factory()).query餐廳(id));
                        }                     
                        foreach (s餐廳 i in list所有餐廳)
                        {
                            cbox餐廳.Items.Add(i.f餐廳名稱);
                        }
                    }
            
                    else
                    {                  
                        List<int> list餐廳id = list訂單明細Now.Select(order => order.a餐廳Id).Distinct().OrderBy(e => e).ToList();
                        list所有餐廳.Clear();
                        foreach (int id in list餐廳id)
                        {
                            list所有餐廳.Add((new s餐廳Factory()).query餐廳(id));
                        }
                        foreach (s餐廳 i in list所有餐廳)
                        {
                            cbox餐廳.Items.Add(i.f餐廳名稱);
                        }
                    }
                }
            }
        }

        void 搜索訂購班級()
        {
            cbox訂購單位.Items.Clear();

            if (GlobalOrder.e目前訂購人.f值日生權限)
            {
                if (GlobalOrder.list訂單明細.Count > 0)
                {
                    if (判斷是否為管理員)
                    {
                        List<int> list訂購單位id = GlobalOrder.list訂單明細.Select(order => order.a單位Id).Distinct().OrderBy(e => e).ToList();
                        list所有訂購單位.Clear();
                        foreach (int id in list訂購單位id)
                        {
                            list所有訂購單位.Add((new s訂購班級Factory()).query指定訂購單位Id(id));
                        }
                        foreach (s訂購班級 i in list所有訂購單位)
                        {
                            cbox訂購單位.Items.Add(i.f訂購單位);
                        }
                    }
                    else
                    {
                        list所有訂購單位.Clear();
                        list所有訂購單位.Add(GlobalOrder.e目前訂購單位);
                        cbox訂購單位.Items.Add(GlobalOrder.e目前訂購單位.f訂購單位);

                    }
                }
            }
        }

        void 搜索訂購人(int f訂購單位id)
        {
            cbox訂購人.Items.Clear();

            if (GlobalOrder.e目前訂購人.f值日生權限)
            {
                if (GlobalOrder.list訂單明細.Count > 0)
                {
                    List<int> list訂購人id = GlobalOrder.list訂單明細.Where(order => order.a單位Id == f訂購單位id).Select(order => order.f訂購人Id).Distinct().OrderBy(e => e).ToList();
                    list目前單位訂購人.Clear();
                    foreach (int id in list訂購人id)
                    {
                        list目前單位訂購人.Add((new s訂購人Factory()).query訂購人(id));
                    }

                    foreach (s訂購人 p in list目前單位訂購人)
                    {
                        cbox訂購人.Items.Add($"{p.f姓名}[{p.fId}]");
                    }
                }
            }
        }

        private void btn移除訂單_Click(object sender, EventArgs e)
        {
            if (判斷是否搜索到班級)
            {

                for (int i = lbox訂單列表.SelectedIndices.Count - 1; i >= 0; i--)
                {
                    GlobalOrder.list訂單明細.RemoveAt(list搜尋訂單明細[lbox訂單列表.SelectedIndices[i]].indexIn總訂單);
                }
                int temp單位 = int搜尋訂購單位Id;
                int temp訂購人 = -1;

                if (int搜尋訂購人Id > -1)
                {
                    temp訂購人 = int搜尋訂購人Id;

                    重置訂單(GlobalOrder.e目前訂購人.f值日生權限);

                    bool is刪除後包含搜尋單位 = false;
                    if (list所有訂購單位.Count > 0)
                    {
                        is刪除後包含搜尋單位 = list所有訂購單位.Select(org => org.fId).Contains(temp單位);
                    }
                    if (is刪除後包含搜尋單位)
                    {

                        int[] x = list所有訂購單位.Select(org => org.fId).ToArray();
                        int index = Array.IndexOf(x, temp單位);

                        int搜尋訂購單位Id = temp單位;
                        cbox訂購單位.SelectedIndex = index;

                        bool is刪除後包含搜尋訂購人 = false;
                        if (list目前單位訂購人.Count > 0)
                        {
                            is刪除後包含搜尋訂購人 = list目前單位訂購人.Select(p => p.fId).Contains(temp訂購人);
                        }
                        if (is刪除後包含搜尋訂購人)
                        {
                            int[] person = list目前單位訂購人.Select(p => p.fId).ToArray();
                            int indexPerson = Array.IndexOf(person, temp訂購人);

                            int搜尋訂購人Id = temp訂購人;
                            cbox訂購人.SelectedIndex = indexPerson;

                            搜索班級訂購();
                        }
                    }
                }

                else
                {

                    重置訂單(GlobalOrder.e目前訂購人.f值日生權限);

                    bool is刪除後包含搜尋單位 = false;
                    if (list所有訂購單位.Count > 0)
                    {
                        is刪除後包含搜尋單位 = list所有訂購單位.Select(org => org.fId).Contains(temp單位);
                    }
                    if (is刪除後包含搜尋單位)
                    {
       
                        int[] x = list所有訂購單位.Select(org => org.fId).ToArray();
                        int index = Array.IndexOf(x, temp單位);
 
                        int搜尋訂購單位Id = temp單位;
                        cbox訂購單位.SelectedIndex = index;
                        
                        搜索班級訂購();
                    }
                }
            }
            else if (判斷是否搜索到餐廳)
            {
                for (int i = lbox訂單列表.SelectedIndices.Count - 1; i >= 0; i--)
                {
                    GlobalOrder.list訂單明細.RemoveAt(list搜尋訂單明細[lbox訂單列表.SelectedIndices[i]].indexIn總訂單);
                }
                int temp = int搜尋餐廳Id;

                重置訂單(GlobalOrder.e目前訂購人.f值日生權限);

                bool is刪除後包含搜尋餐廳 = false;
                if (list所有餐廳.Count > 0)
                {
                    is刪除後包含搜尋餐廳 = list所有餐廳.Select(store => store.fId).Contains(temp);
                }
                if (is刪除後包含搜尋餐廳)
                {
                    int[] x = list所有餐廳.Select(store => store.fId).ToArray();
                    int index = Array.IndexOf(x, temp);

                    int搜尋餐廳Id = list所有餐廳[index].fId;
                    cbox餐廳.SelectedIndex = index;

                    搜索餐廳訂購();
                }
            }
            else
            {
                if (判斷是否為管理員)
                {
                    for (int i = lbox訂單列表.SelectedIndices.Count - 1; i >= 0; i--)
                    {
                        GlobalOrder.list訂單明細.RemoveAt(lbox訂單列表.SelectedIndices[i]);
                    }
                }
                else
                {
                    for (int i = lbox訂單列表.SelectedIndices.Count - 1; i >= 0; i--)
                    {
                        GlobalOrder.list訂單明細.RemoveAt(list訂單明細Now[lbox訂單列表.SelectedIndices[i]].indexIn總訂單);
                    }
                }
                重置訂單(GlobalOrder.e目前訂購人.f值日生權限);
            }
        }

        private void btn全部清空_Click(object sender, EventArgs e)
        {
            if ( (判斷是否搜索到班級) || (判斷是否搜索到餐廳) )
            {
                for (int i = list搜尋訂單明細.Count - 1; i >= 0; i--)
                {
                    GlobalOrder.list訂單明細.RemoveAt(list搜尋訂單明細[i].indexIn總訂單);
                }
                重置訂單(GlobalOrder.e目前訂購人.f值日生權限);
            }
            else
            {
                if (判斷是否為管理員)
                {
                    GlobalOrder.list訂單明細.Clear();
                }
                else
                {
                    for (int i = list訂單明細Now.Count - 1; i >= 0; i--)
                    {
                        GlobalOrder.list訂單明細.RemoveAt(list訂單明細Now[i].indexIn總訂單);
                    }
                }
                重置訂單(GlobalOrder.e目前訂購人.f值日生權限);
            }
        }

        private void cbox訂購單位_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbox訂購單位.SelectedIndex > -1)
            {
                判斷是否搜索到班級 = true;
                判斷是否搜索到餐廳 = false;
                cbox餐廳.Enabled = false;

                int搜尋訂購人Id = -1;
                cbox訂購人.Text = "";

                int搜尋訂購單位Id = list所有訂購單位[cbox訂購單位.SelectedIndex].fId;

                搜索訂購人(int搜尋訂購單位Id);
            }
        }

        private void cbox訂購人_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbox訂購人.SelectedIndex > -1)
            {
                判斷是否搜索到班級 = true;
                判斷是否搜索到餐廳 = false;
                cbox餐廳.Enabled = false;

                int搜尋訂購人Id = list目前單位訂購人[cbox訂購人.SelectedIndex].fId;
            }
        }
        
        private void cbox餐廳_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbox餐廳.SelectedIndex > -1)
            {
                判斷是否搜索到班級 = false;
                判斷是否搜索到餐廳 = true;
                cbox訂購單位.Enabled = false;
                cbox訂購人.Enabled = false;

                int搜尋餐廳Id = list所有餐廳[cbox餐廳.SelectedIndex].fId;
            }
        }
        
        private void btn資料篩選_Click(object sender, EventArgs e)
        {
            if (判斷是否搜索到班級)
            {
                搜索班級訂購();
            }
            else if (判斷是否搜索到餐廳)
            {
                搜索餐廳訂購();
            }
            else
            {
                MessageBox.Show("請選擇篩選條件！", "篩選結果", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        void 搜索班級訂購()
        {
            lbox訂單列表.Items.Clear();

            if (GlobalOrder.list訂單明細.Count > 0)
            {
                if (int搜尋訂購人Id > -1)
                {
                    if (判斷是否為管理員)
                    {
                        list搜尋訂單明細.Clear();
                        int i = 0;
                        s訂單明細 x;
                        foreach (s訂單明細 item in GlobalOrder.list訂單明細)
                        {
                            if (item.f訂購人Id == int搜尋訂購人Id)
                            {
                                x = new s訂單明細();
                                x.f訂購人Id = item.f訂購人Id;
                                x.f餐點Id = item.f餐點Id;
                                x.f數量 = item.f數量;
                                x.a單位Id = item.a單位Id;
                                x.a餐廳Id = item.a餐廳Id;
                                x.indexIn總訂單 = i;
                                list搜尋訂單明細.Add(x);
                            }
                            i++;
                        }

                        if (list搜尋訂單明細.Count > 0)
                        {
                            s訂購班級 s班級;
                            s訂購人 s人;
                            s餐點 s餐;
                            s餐廳 s廳;
                            foreach (s訂單明細 item in list搜尋訂單明細)
                            {
                                s班級 = (new s訂購班級Factory()).query指定訂購單位Id(item.a單位Id);
                                s人 = (new s訂購人Factory()).query訂購人(item.f訂購人Id);
                                s餐 = (new s餐點Factory()).queryById(item.f餐點Id);
                                s廳 = (new s餐廳Factory()).query餐廳(item.a餐廳Id);

                                lbox訂單列表.Items.Add($"{s班級.f訂購單位} {s人.f姓名}[{s人.fId}]：{s廳.f餐廳名稱} {s餐.f餐點} {item.f數量}份 單價 {s餐.f價格} 元");
                            }
                           
                            total計算總價(list搜尋訂單明細);
                        }
                    }
                   
                    else
                    {
                      
                        list搜尋訂單明細.Clear();
                        s訂單明細 s;
                        foreach (s訂單明細 item in list訂單明細Now)
                        {
                            if (item.f訂購人Id == int搜尋訂購人Id)
                            {
                                s = new s訂單明細();
                                s.f訂購人Id = item.f訂購人Id;
                                s.f餐點Id = item.f餐點Id;
                                s.f數量 = item.f數量;
                                s.a單位Id = item.a單位Id;
                                s.a餐廳Id = item.a餐廳Id;
                                s.indexIn總訂單 = item.indexIn總訂單;
                                list搜尋訂單明細.Add(s);
                            }
                        }

                        if (list搜尋訂單明細.Count > 0)
                        {

                            s訂購班級 s班級;
                            s訂購人 s人;
                            s餐點 s餐;
                            s餐廳 s廳;
                            foreach (s訂單明細 item in list搜尋訂單明細)
                            {
                                s班級 = (new s訂購班級Factory()).query指定訂購單位Id(item.a單位Id);
                                s人 = (new s訂購人Factory()).query訂購人(item.f訂購人Id);
                                s餐 = (new s餐點Factory()).queryById(item.f餐點Id);
                                s廳 = (new s餐廳Factory()).query餐廳(item.a餐廳Id);

                                lbox訂單列表.Items.Add($"{s班級.f訂購單位} {s人.f姓名}[{s人.fId}]：{s廳.f餐廳名稱} {s餐.f餐點} {item.f數量}份 單價 {s餐.f價格} 元");
                            }
                         
                            total計算總價(list搜尋訂單明細);
                        }
                    }
                }
            
                else
                {
                    
                    if (判斷是否為管理員)
                    {
                       
                        list搜尋訂單明細.Clear();
                        int i = 0;
                        s訂單明細 s;
                        foreach (s訂單明細 item in GlobalOrder.list訂單明細)
                        {
                            if (item.a單位Id == int搜尋訂購單位Id)
                            {
                                s = new s訂單明細();
                                s.f訂購人Id = item.f訂購人Id;
                                s.f餐點Id = item.f餐點Id;
                                s.f數量 = item.f數量;
                                s.a單位Id = item.a單位Id;
                                s.a餐廳Id = item.a餐廳Id;
                                s.indexIn總訂單 = i;
                                list搜尋訂單明細.Add(s);
                            }
                            i++;
                        }

                        if (list搜尋訂單明細.Count > 0)
                        {
                            s訂購班級 s班級;
                            s訂購人 s人;
                            s餐點 s餐;
                            s餐廳 s廳;
                            foreach (s訂單明細 item in list搜尋訂單明細)
                            {
                                s班級 = (new s訂購班級Factory()).query指定訂購單位Id(item.a單位Id);
                                s人 = (new s訂購人Factory()).query訂購人(item.f訂購人Id);
                                s餐 = (new s餐點Factory()).queryById(item.f餐點Id);
                                s廳 = (new s餐廳Factory()).query餐廳(item.a餐廳Id);

                                lbox訂單列表.Items.Add($"{s班級.f訂購單位} {s人.f姓名}[{s人.fId}]：{s廳.f餐廳名稱} {s餐.f餐點} {item.f數量}份 單價 {s餐.f價格} 元");
                            }
                            total計算總價(list搜尋訂單明細);
                        }
                    }
                    else
                    {
                        重置訂單(GlobalOrder.e目前訂購人.f值日生權限);
                    }
                }
            }
        }

        void 搜索餐廳訂購()
        {
            lbox訂單列表.Items.Clear();

            if (GlobalOrder.list訂單明細.Count > 0)
            {
                if (判斷是否為管理員)
                {
                    list搜尋訂單明細.Clear();
                    int i = 0;
                    s訂單明細 s;
                    foreach (s訂單明細 item in GlobalOrder.list訂單明細)
                    {
                        if (item.a餐廳Id == int搜尋餐廳Id)
                        {
                            s = new s訂單明細();
                            s.f訂購人Id = item.f訂購人Id;
                            s.f餐點Id = item.f餐點Id;
                            s.f數量 = item.f數量;
                            s.a單位Id = item.a單位Id;
                            s.a餐廳Id = item.a餐廳Id;
                            s.indexIn總訂單 = i;
                            list搜尋訂單明細.Add(s);
                        }
                        i++;
                    }

                    if (list搜尋訂單明細.Count > 0)
                    {
                        s訂購班級 s班級;
                        s訂購人 s人;
                        s餐點 s餐;
                        s餐廳 s廳;
                        foreach (s訂單明細 item in list搜尋訂單明細)
                        {
                            s班級 = (new s訂購班級Factory()).query指定訂購單位Id(item.a單位Id);
                            s人 = (new s訂購人Factory()).query訂購人(item.f訂購人Id);
                            s餐 = (new s餐點Factory()).queryById(item.f餐點Id);
                            s廳 = (new s餐廳Factory()).query餐廳(item.a餐廳Id);

                            lbox訂單列表.Items.Add($"{s班級.f訂購單位} {s人.f姓名}[{s人.fId}]：{s廳.f餐廳名稱} {s餐.f餐點} {item.f數量}份 單價 {s餐.f價格} 元");
                        }
                        total計算總價(list搜尋訂單明細);
                    }
                }
                else
                {
                    list搜尋訂單明細.Clear();
                    s訂單明細 s;
                    foreach (s訂單明細 item in list訂單明細Now)
                    {
                        if (item.a餐廳Id == int搜尋餐廳Id)
                        {
                            s = new s訂單明細();
                            s.f訂購人Id = item.f訂購人Id;
                            s.f餐點Id = item.f餐點Id;
                            s.f數量 = item.f數量;
                            s.a單位Id = item.a單位Id;
                            s.a餐廳Id = item.a餐廳Id;
                            s.indexIn總訂單 = item.indexIn總訂單;
                            list搜尋訂單明細.Add(s);
                        }
                    }

                    if (list搜尋訂單明細.Count > 0)
                    {
                        s訂購班級 s班級;
                        s訂購人 s人;
                        s餐點 s餐;
                        s餐廳 s廳;
                        foreach (s訂單明細 item in list搜尋訂單明細)
                        {
                            s班級 = (new s訂購班級Factory()).query指定訂購單位Id(item.a單位Id);
                            s人 = (new s訂購人Factory()).query訂購人(item.f訂購人Id);
                            s餐 = (new s餐點Factory()).queryById(item.f餐點Id);
                            s廳 = (new s餐廳Factory()).query餐廳(item.a餐廳Id);

                            lbox訂單列表.Items.Add($"{s班級.f訂購單位} {s人.f姓名}[{s人.fId}]：{s廳.f餐廳名稱} {s餐.f餐點} {item.f數量}份 單價 {s餐.f價格} 元");
                        }
                        total計算總價(list搜尋訂單明細);
                    }
                }
            }
        }

        private void btn重置篩選_Click(object sender, EventArgs e)
        {
            重置訂單(GlobalOrder.e目前訂購人.f值日生權限);
        }
    
        private void btn另存訂單_Click(object sender, EventArgs e)
        {
            try
            {            
                string str完整路徑 = "";
                SaveFileDialog sfd = new SaveFileDialog();
                sfd.Filter = "Txt File|*.txt";

              
                Random myRnd = new Random();
                int myRndNum = myRnd.Next(1000, 10000);
                string str檔名 = DateTime.Now.ToString("yyyyMMdd_HHmmss_") + myRndNum.ToString() + "_" + GlobalOrder.e目前訂購單位.f訂購單位 + @"_全端便當訂購系統訂購單.txt";
                sfd.FileName = str檔名;

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    str完整路徑 = sfd.FileName;
                }
                else
                {
                    return;
                }

                List<string> lines所有訂單 = new List<string>();
                
                lines所有訂單.Add("============ 全端店當訂購系統 訂購單 ============");
                lines所有訂單.Add("訂購時間：" + DateTime.Now.ToString());
                lines所有訂單.Add("=============================================");
                
                List<s訂單明細> list統一訂單列表;
                if (判斷是否為管理員)
                    list統一訂單列表 = GlobalOrder.list訂單明細;
                else
                    list統一訂單列表 = list訂單明細Now;
                
                int total店小計金額;
                int total餐小計金額;
                int total餐小計數量;
                List<s餐點> list指定餐點;
                foreach (s餐廳 store in list所有餐廳)
                {
                    lines所有訂單.Add($"======== {store.f餐廳名稱}[{store.f餐廳電話}] ========");

                    total店小計金額 = 0;
                    
                    list指定餐點 = find指定餐廳在列表中所有餐點(store.fId, list統一訂單列表);
                    foreach (s餐點 food in list指定餐點)
                    {
                        lines所有訂單.Add($"【{food.f餐點}】");

                        total餐小計金額 = 0;
                        total餐小計數量 = 0;
                        foreach (s訂單明細 item in list統一訂單列表)
                        {
                            s訂購班級 s班級= (new s訂購班級Factory()).query指定訂購單位Id(item.a單位Id);
                            s訂購人 s人 = (new s訂購人Factory()).query訂購人(item.f訂購人Id);
                            s餐點 s餐 = (new s餐點Factory()).queryById(item.f餐點Id);
                            s餐廳 s廳 = (new s餐廳Factory()).query餐廳(item.a餐廳Id);

                            if (food.fId == s餐.fId)
                            {
                                total店小計金額 += item.f數量 * s餐.f價格;
                                total餐小計金額 += item.f數量 * s餐.f價格;
                                total餐小計數量 += item.f數量;
                                lines所有訂單.Add($"{s班級.f訂購單位} {s人.f姓名}[{s人.fId}]：訂購 {s餐.f價格}元 x {item.f數量}個");
                            }
                        }
                        lines所有訂單.Add($"【餐小計：{total餐小計數量}個 {total餐小計金額} 元】");
                        lines所有訂單.Add($"----------------------");
                    }
                    lines所有訂單.Add($"===== 總價：{total店小計金額} 元 =====");
                }

                lines所有訂單.Add("=============================================");
                lines所有訂單.Add("合計總價：" + total計算總價(list統一訂單列表) + " 元");

                System.IO.File.WriteAllLines(str完整路徑, lines所有訂單, Encoding.UTF8);
                MessageBox.Show("另存訂單成功！", "另存訂單結果", MessageBoxButtons.OK, MessageBoxIcon.Information);

               
                s訂單 new訂單 = new s訂單();
                new訂單.f訂單時間 = DateTime.Now;
                (new s訂單Factory()).create(new訂單);              
                s訂單 indb訂單 = (new s訂單Factory()).query最新訂單();
                if (indb訂單 != null)
                {
                    s訂單明細 new訂單明細;
                    foreach (s訂單明細 item in list統一訂單列表)
                    {
                        new訂單明細 = new s訂單明細();
                        new訂單明細.f訂單Id = indb訂單.fId;
                        new訂單明細.f訂購人Id = item.f訂購人Id;
                        new訂單明細.f餐點Id = item.f餐點Id;
                        new訂單明細.f數量 = item.f數量;
                        (new s訂單明細Factory()).create(new訂單明細);
                    }
                }

              
                if (!判斷是否為管理員)
                {
                    s訂購人 next = (new s訂購人Factory()).next值日生(GlobalOrder.e目前訂購人);
                    if (next != null)
                    {
                        s訂購人 old訂購人 = new s訂購人();
                        old訂購人.fId = GlobalOrder.e目前訂購人.fId;
                        old訂購人.f值日生權限 = false;
                        (new s訂購人Factory()).update(old訂購人);
                        s訂購人 new訂購人 = new s訂購人();
                        new訂購人.fId = next.fId;
                        new訂購人.f值日生權限 = true;
                        (new s訂購人Factory()).update(new訂購人);

                        
                        s訂購人 update訂購人 = (new s訂購人Factory()).query訂購人(old訂購人.fId);
                        if (update訂購人 != null)
                        {
                            GlobalOrder.e目前訂購人 = update訂購人;
                            重置訂單(GlobalOrder.e目前訂購人.f值日生權限);
                        }
                        else
                        {
                            MessageBox.Show("更新GlobalOrder失敗");
                        }
                    }
                    else
                    {
                        MessageBox.Show("輪換值日生失敗");
                    }
                }

                this.Close();
            }
            catch (Exception error)
            {
                MessageBox.Show("另存訂單失敗：" + Convert.ToString(error), "另存訂單結果");
            }
        }

      
        List<s餐點> find指定餐廳在列表中所有餐點(int f餐廳Id, List<s訂單明細> list訂單明細)
        {
            int[] x = list訂單明細.Where(order => order.a餐廳Id == f餐廳Id).Select(order => order.f餐點Id).Distinct().OrderBy(e => e).ToArray();
            List<s餐點> list指定餐點 = new List<s餐點>();
            s餐點 c餐;
            foreach (int id餐點 in x)
            {
                c餐 = (new s餐點Factory()).queryById(id餐點);
                list指定餐點.Add(c餐);
            }
            return list指定餐點;
        }
    }
}